using Installer;
using WixSharp;
using WixSharp.CommonTasks;
using WixSharp.Controls;

if (args.Length < 2) throw new ArgumentException("Usage: Installer <version> <publishDir1> [publishDir2 ...]");
const string outputName = "AP-BIM-Tools";
const string projectName = "AP-BIM Tools";
var versioning = Versioning.CreateFromVersionString(args[0]);
var project = new Project
{
    OutDir = "output",
    Name = projectName,
    Platform = Platform.x64,
    UI = WUI.WixUI_FeatureTree,
    MajorUpgrade = MajorUpgrade.Default,
    GUID = new Guid("39A83E67-0A17-48A0-B328-68386F8CE19B"),
    BannerImage = @"install\Resources\Icons\BannerImage.png",
    BackgroundImage = @"install\Resources\Icons\BackgroundImage.png",
    Version = versioning.VersionPrefix,
    ControlPanelInfo = { Manufacturer = "AP", ProductIcon = @"install\Resources\Icons\ShellIcon.ico" }
};
var wixEntities = Generator.GenerateWixEntities(args[1..]);
project.RemoveDialogsBetween(NativeDialogs.WelcomeDlg, NativeDialogs.CustomizeDlg);
project.Scope = InstallScope.perMachine;
project.OutFileName = $"{outputName}-{versioning.Version}";
project.Dirs = wixEntities.GroupBy(entity => entity.Version switch { >= 2027 => @"%ProgramFiles%\Autodesk\Revit\Addins", _ => @"%CommonAppDataFolder%\Autodesk\Revit\Addins" })
    .Select(root => new Dir(root.Key, [.. root.Select(entity => entity.Directory)])).ToArray();
project.BuildMsi();
