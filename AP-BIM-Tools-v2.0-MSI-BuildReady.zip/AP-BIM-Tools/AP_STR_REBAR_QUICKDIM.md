# AP-STR — Rebar & Quick Dim (v1.1)

## Rebar

### Beam 4 Bars
1. Select one or more horizontal structural framing family instances.
2. Run **AP-STR > Rebar > Beam 4 Bars**.
3. Enter nominal bar diameter and concrete cover in mm.
4. AP chooses the closest Rebar Bar Type already loaded in the project and creates 4 straight corner longitudinal bars.

### Beam Stirrups
1. Select horizontal beams.
2. Enter stirrup diameter, cover and maximum spacing.
3. AP creates a closed stirrup shape-driven set and applies Revit Maximum Spacing layout.

### Column 4 Bars / Column Ties
Same workflow for vertical structural columns. Rotated vertical columns are supported; slanted columns are skipped.

### Utilities
- **Set Rebar Spacing** — updates selected shape-driven rebar sets to Maximum Spacing.
- **Number Rebar** — renumbers selected rebar; if none are selected, all rebar is considered.
- **Rebar by Host** — select concrete hosts first, then select their hosted rebar.
- **Rebar Audit** — checks host, mark, quantity and total length and exports CSV.
- Existing **Rebar Report / Solid / Visible** tools remain available.

### Safety / scope
The automatic modeling commands are drafting/modeling productivity helpers, not reinforcement design software. They do not calculate required reinforcement from loads or code checks. They intentionally skip sloped beams, slanted columns and unsupported geometry. Verify generated reinforcement, cover, anchorage/lap, congestion, bar shape and spacing before issue.

## Quick Dim

### Dim Grid
- If 2+ grids are selected, AP dimensions only those grids.
- Otherwise it dimensions visible straight grids in the active view.
- Parallel grids are grouped automatically and dimensioned as chained strings.

### Dim Level
- Runs in section/elevation views.
- If 2+ levels are selected, AP uses those; otherwise it uses visible levels.

### Dim Wall Plan
- Select one or more straight basic walls.
- AP uses the actual Interior/Exterior wall face references and creates a dimension string per parallel group.
- A single wall can therefore receive a wall-thickness dimension.

### Dim Pile Plan
- Select 2+ pile instances for the safest workflow.
- With no selection, AP only auto-detects structural foundation families/types containing Pile, Cọc/Coc, PHC or Spun.
- Dimensions use the family Center (Left/Right) and Center (Front/Back) references.

### Dim Column Plan
- Uses selected structural columns; if none are selected, visible structural columns are used.
- Creates center-to-center dimension strings in the two family reference directions.

### Family requirement for pile/column dimensioning
The family should expose dimensionable center reference planes:
- Center (Left/Right)
- Center (Front/Back)

If those reference planes are set to **Not a Reference**, Revit does not expose usable family-instance references and AP will skip them.
