# AP-BIM Tools

A modular Autodesk Revit productivity add-in built on the Nice3point RevitTemplates 6.2.3 architecture.

## Ribbon tabs
- **AP-ARCH** — Architecture modelling, rooms, openings/joins and documentation helpers
- **AP-STR** — Structural framing, marks, rebar and QA/QC
- **AP-MEP** — MEP connectivity, QA/QC, quick clash and system data
- **AP-GEN** — General productivity, model health, selection, links/CAD and reports

## Supported configurations
Revit 2023, 2024, 2025, 2026 and 2027 via `Debug.R23...R27` and `Release.R23...R27`.

## Prerequisites
1. Visual Studio 2022/2026 or JetBrains Rider with the .NET SDK required by Nice3point.Revit.Sdk 6.2.3.
2. Internet access for the first NuGet restore.
3. One or more supported Revit versions installed for local testing/deployment.

## Build
```powershell
dotnet restore .\AP-BIM-Tools.slnx
dotnet build .\AP-BIM-Tools.slnx -c Release.R26
```
Or build all configured versions:
```powershell
.\build-release.ps1
```

The Nice3point SDK handles Revit API references, target framework selection, manifest patching, repacking and add-in deployment.

## Reports
CSV reports are written to:
`%USERPROFILE%\Documents\AP-BIM Tools\Reports`

Logs are written to:
`%LOCALAPPDATA%\AP\AP-BIM Tools\Logs`

## Important safeguards
Bulk renumbering uses current selection when suitable; otherwise it falls back to the relevant project category. Commands that affect broad sets of views/sheets request confirmation. Always test on a detached/copy model before adopting a new automation tool in production.



## v2.0 — AP-Rebar Engine

AP-STR now contains **AP-Rebar Studio** with dedicated Beam Axis, Column, Wall, Slab and Foundation workflows, plus Column→Foundation starter bars, persistent presets, safe replace/update, BBS export, native Revit schedules, 3D review and automatic detail sections. See `AP_REBAR_ENGINE.md` for the full behavior and safeguards.

The existing Quick Dim tools remain: Grid, Level, Wall Plan, Pile Plan and Column Plan.

### Important engineering limitation
AP-Rebar automates modeling from user-supplied bar sizes, cover, counts and spacing. It does **not** calculate required reinforcement from structural analysis and does not replace an engineer's code/design checks. Unsupported geometry is intentionally skipped/rolled back.
