AP-BIM Tools v2.0 - MSI build package

This source is configured to build Revit 2023-2027 and create:
  install/output/AP-BIM-Tools-2.0.0.msi

Recommended build environment:
  Windows x64
  .NET SDK 10.0.110 or compatible 10.0.x
  Internet access to NuGet

Fast path:
  1. Open PowerShell in this folder.
  2. Run: .\build-release.ps1
  3. MSI output: .\install\output\AP-BIM-Tools-2.0.0.msi

GitHub Actions:
  Push this repository to GitHub and run workflow "Build AP-BIM Tools".
  The workflow uploads artifact AP-BIM-Tools-2.0.0 including the MSI.
