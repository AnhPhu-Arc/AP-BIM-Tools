# AP-BIM Tools 2.0 — Feature Matrix

## AP-STR — AP-Rebar Engine

| Area | AP implementation | Status |
|---|---|---|
| Rebar Studio | One configuration UI for Beam / Column / Wall / Slab / Foundation | Implemented |
| Beam axis | Top/bottom bars, extra support bars, 3 stirrup zones, batch selected spans | Implemented for straight horizontal beams |
| Column | Perimeter main bars, 3 tie zones | Implemented for vertical regular columns |
| Column → foundation | Starter bars with configurable embed/projection | Implemented; nearest containing foundation search |
| Wall | Vertical/horizontal bars, one/two faces, boundary bars | Implemented for straight walls; multi-level batch via selection |
| Slab | Top/bottom X/Y mats with independent bar sizes/spacing | Implemented for regular horizontal slabs |
| Foundation | Top/bottom X/Y mats | Implemented for regular structural-foundation families |
| Presets | Persistent defaults + Apply Saved Preset | Implemented |
| Safe update | Per-host SubTransaction; failed hosts rollback and retain old rebar | Implemented |
| BBS | Aggregated CSV including estimated kg | Implemented |
| Revit schedule | Native Rebar schedule with core fields | Implemented |
| 3D review | Cropped Fine-detail review view | Implemented |
| Detail sections | Automatic cropped section views by selected hosts | Implemented for supported orientations |
| QA/QC | Rebar audit/report, visibility, select by host | Implemented |
| Curved/sloped/irregular reinforcement | Dedicated geometry algorithms | Not claimed in 2.0 |
| Pre-commit visual preview | Transient graphics preview | Not claimed in 2.0 |
| Full automatic sheet/tag/dimension detailing | Project-specific detailing rules | Partial: views + schedules; tags/sheets require standards |

## AP-STR — Quick Dim
- Grid chained dimensions.
- Level chained dimensions.
- Wall plan face dimensions.
- Pile plan center dimensions in two directions.
- Column plan center dimensions in two directions.

## AP-ARCH
- Room → Floor / Ceiling.
- Door facing / hand flip.
- Wall join controls.
- Room audit, renumbering and export.
- Door/window renumber and selection utilities.

## AP-MEP
- Connect nearest open connectors.
- Offset editing.
- Open connector/fitting/space audits.
- Quick clash screening.
- System and MEP exports.

## AP-GEN
- Model Health / Warning Summary.
- Link and CAD reports.
- Project coordinates.
- Selection / pin / isolate helpers.
- View/sheet naming helpers.
- Selection export and Purge launcher.
