# Third-party notices

AP-BIM Tools is scaffolded from concepts and sample structure in Nice3point/RevitTemplates, licensed under the MIT License.
Keep the original Nice3point MIT notice when redistributing portions copied from that repository.
NuGet dependencies retain their respective licenses.

No BIMSpeed source code, assets, or proprietary implementation is included in this project.
