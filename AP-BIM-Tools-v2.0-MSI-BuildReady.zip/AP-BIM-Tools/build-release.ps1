$ErrorActionPreference = "Stop"
$versions = @("R23","R24","R25","R26","R27")
foreach ($v in $versions) {
  dotnet build .\AP-BIM-Tools.slnx -c "Release.$v"
}
$publish = @(
  ".\source\AP.BimTools\bin\publish\2023",
  ".\source\AP.BimTools\bin\publish\2024",
  ".\source\AP.BimTools\bin\publish\2025",
  ".\source\AP.BimTools\bin\publish\2026",
  ".\source\AP.BimTools\bin\publish\2027"
)
dotnet run --project .\install\Installer.csproj -- 2.0.0 @publish
Write-Host "Build completed. MSI: install/output/AP-BIM-Tools-2.0.0.msi"
