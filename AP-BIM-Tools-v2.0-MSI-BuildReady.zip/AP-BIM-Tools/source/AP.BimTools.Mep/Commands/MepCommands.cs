using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;
using Autodesk.Revit.UI;
using Nice3point.Revit.Toolkit.External;
using AP.BimTools.Core;
using AP.BimTools.Core.Services;
using AP.BimTools.Core.UI;
using AP.BimTools.Core.Utilities;

namespace AP.BimTools.Mep.Commands;

internal static class MepHelpers
{
    public static List<Element> InstancesOf(Document doc, BuiltInCategory category) =>
        new FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType().ToElements().ToList();

    public static List<Element> MepCurves(Document doc) => new FilteredElementCollector(doc).WhereElementIsNotElementType()
        .Where(e => e is Pipe or Duct or Conduit or CableTray).ToList();

    public static List<Element> MepFittings(Document doc) =>
        new[] { BuiltInCategory.OST_PipeFitting, BuiltInCategory.OST_DuctFitting, BuiltInCategory.OST_ConduitFitting, BuiltInCategory.OST_CableTrayFitting }
            .SelectMany(c => InstancesOf(doc, c)).ToList();

    public static List<Element> OpenConnectorOwners(Document doc) => MepCurves(doc).Concat(MepFittings(doc))
        .Where(e => ConnectorUtils.GetOpenPhysicalConnectors(e).Any()).Distinct().ToList();

    public static string SystemName(Element e) => e.get_Parameter(BuiltInParameter.RBS_SYSTEM_NAME_PARAM)?.AsString() ?? "";
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ConnectTwoElementsCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument);
        if (selected.Count != 2) { TaskDialog.Show(ProductInfo.Name, "Select exactly two MEP elements."); return; }
        var a = ConnectorUtils.GetOpenPhysicalConnectors(selected[0]).ToList();
        var b = ConnectorUtils.GetOpenPhysicalConnectors(selected[1]).ToList();
        if (a.Count == 0 || b.Count == 0) { TaskDialog.Show(ProductInfo.Name, "One or both elements have no open end connector."); return; }
        var pair = (from c1 in a from c2 in b where c1.Domain == c2.Domain orderby c1.Origin.DistanceTo(c2.Origin) select (c1, c2)).FirstOrDefault();
        if (pair.c1 is null || pair.c2 is null) { TaskDialog.Show(ProductInfo.Name, "No compatible connector domains found."); return; }
        string result = "";
        TransactionUtils.Run(ActiveDocument, "AP - Connect nearest MEP", () =>
        {
            try { ActiveDocument.Create.NewElbowFitting(pair.c1, pair.c2); result = "Elbow fitting created."; return; } catch { }
            try { ActiveDocument.Create.NewUnionFitting(pair.c1, pair.c2); result = "Union fitting created."; return; } catch { }
            try { pair.c1.ConnectTo(pair.c2); result = "Connectors connected directly."; return; } catch { }
            throw new InvalidOperationException("Revit could not create a valid connection between the selected connectors.");
        });
        TaskDialog.Show(ProductInfo.Name, result);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SetOffsetCommand : ExternalCommand
{
    public override void Execute()
    {
        var mm = PromptDialog.AskDouble("AP - Set MEP Offset", "Offset (mm):", 0); if (mm is null) return;
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument);
        var internalValue = UnitUtils.ConvertToInternalUnits(mm.Value, UnitTypeId.Millimeters);
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Set MEP offset", () =>
        {
            foreach (var e in selected)
            {
                var p = e.get_Parameter(BuiltInParameter.RBS_OFFSET_PARAM);
                if (p is null || p.IsReadOnly || p.StorageType != StorageType.Double) continue;
                try { p.Set(internalValue); changed++; } catch { }
            }
        });
        TaskDialog.Show(ProductInfo.Name, $"Updated offset on {changed}/{selected.Count} selected element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class MepAuditCommand : ExternalCommand
{
    public override void Execute()
    {
        var pipes = MepHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_PipeCurves);
        var ducts = MepHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_DuctCurves);
        var conduits = MepHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_Conduit);
        var trays = MepHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_CableTray);
        var fittings = MepHelpers.MepFittings(ActiveDocument);
        var open = MepHelpers.OpenConnectorOwners(ActiveDocument);
        TaskDialog.Show(ProductInfo.Name, $"Pipes: {pipes.Count}\nDucts: {ducts.Count}\nConduits: {conduits.Count}\nCable trays: {trays.Count}\nFittings: {fittings.Count}\nElements with open end connector(s): {open.Count}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectOpenConnectorOwnersCommand : ExternalCommand
{
    public override void Execute()
    {
        var items = MepHelpers.OpenConnectorOwners(ActiveDocument);
        ActiveUiDocument.Selection.SetElementIds(items.Select(e => e.Id).ToList());
        TaskDialog.Show(ProductInfo.Name, $"Selected {items.Count} element(s) with open end connectors.");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class OpenConnectorReportCommand : ExternalCommand
{
    public override void Execute()
    {
        var rows = new List<string[]> { new[] { "ElementId", "Category", "Type", "System", "X_mm", "Y_mm", "Z_mm" } };
        var count = 0;
        foreach (var e in MepHelpers.MepCurves(ActiveDocument).Concat(MepHelpers.MepFittings(ActiveDocument)))
        {
            foreach (var c in ConnectorUtils.GetOpenPhysicalConnectors(e))
            {
                count++;
                var type = ActiveDocument.GetElement(e.GetTypeId())?.Name ?? "";
                rows.Add([e.Id.ToString(), e.Category?.Name ?? "", type, MepHelpers.SystemName(e),
                    UnitUtils.ConvertFromInternalUnits(c.Origin.X, UnitTypeId.Millimeters).ToString("0"),
                    UnitUtils.ConvertFromInternalUnits(c.Origin.Y, UnitTypeId.Millimeters).ToString("0"),
                    UnitUtils.ConvertFromInternalUnits(c.Origin.Z, UnitTypeId.Millimeters).ToString("0")]);
            }
        }
        var path = ReportService.WriteCsv("MEP_Open_Connectors", rows);
        TaskDialog.Show(ProductInfo.Name, $"Open connectors: {count}\n{path}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class FittingAuditCommand : ExternalCommand
{
    public override void Execute()
    {
        var fittings = MepHelpers.MepFittings(ActiveDocument);
        var bad = fittings.Where(f => ConnectorUtils.GetOpenPhysicalConnectors(f).Any()).ToList();
        ActiveUiDocument.Selection.SetElementIds(bad.Select(e => e.Id).ToList());
        TaskDialog.Show(ProductInfo.Name, $"MEP fittings: {fittings.Count}\nFittings with open end connector(s): {bad.Count}\nProblem fittings have been selected.");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class MepClashCommand : ExternalCommand
{
    public override void Execute()
    {
        var mep = SelectionUtils.GetSelectedElements(ActiveUiDocument).Where(e => e is MEPCurve).ToList();
        if (mep.Count == 0) mep = MepHelpers.MepCurves(ActiveDocument);
        var targetCategories = new List<BuiltInCategory>
        {
            BuiltInCategory.OST_Walls, BuiltInCategory.OST_Floors, BuiltInCategory.OST_Roofs,
            BuiltInCategory.OST_StructuralColumns, BuiltInCategory.OST_StructuralFraming, BuiltInCategory.OST_StructuralFoundation
        };
        var clashes = new List<(Element mep, Element host)>();
        var filter = new ElementMulticategoryFilter(targetCategories);
        foreach (var curve in mep)
        {
            var box = curve.get_BoundingBox(null); if (box is null) continue;
            var outline = new Outline(box.Min, box.Max);
            var candidates = new FilteredElementCollector(ActiveDocument).WherePasses(filter).WherePasses(new BoundingBoxIntersectsFilter(outline)).WhereElementIsNotElementType();
            clashes.AddRange(candidates.Where(x => x.Id != curve.Id).Select(host => (curve, host)));
        }
        var unique = clashes.GroupBy(x => $"{x.mep.Id}-{x.host.Id}").Select(g => g.First()).ToList();
        var rows = new List<string[]> { new[] { "MEP Id", "MEP Category", "Host Id", "Host Category" } };
        rows.AddRange(unique.Select(c => new[] { c.mep.Id.ToString(), c.mep.Category?.Name ?? "", c.host.Id.ToString(), c.host.Category?.Name ?? "" }));
        var path = ReportService.WriteCsv("MEP_Quick_Clash", rows);
        TaskDialog.Show(ProductInfo.Name, $"Potential bounding-box clashes: {unique.Count}\n\nThis is a fast screening check, not a geometry-intersection replacement for Navisworks/Revit Interference Check.\n{path}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SpaceAuditCommand : ExternalCommand
{
    public override void Execute()
    {
        var spaces = new FilteredElementCollector(ActiveDocument).OfCategory(BuiltInCategory.OST_MEPSpaces).WhereElementIsNotElementType().Cast<Space>().ToList();
        var unplaced = spaces.Count(s => s.Location is null);
        var zero = spaces.Count(s => s.Location is not null && s.Area <= 0);
        var duplicate = spaces.Where(s => !string.IsNullOrWhiteSpace(s.Number)).GroupBy(s => s.Number).Count(g => g.Count() > 1);
        TaskDialog.Show(ProductInfo.Name, $"MEP Spaces: {spaces.Count}\nUnplaced: {unplaced}\nNot enclosed / zero area: {zero}\nDuplicate numbers: {duplicate}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectPipesCommand : ExternalCommand { public override void Execute() => ActiveUiDocument.Selection.SetElementIds(MepHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_PipeCurves).Select(e => e.Id).ToList()); }
[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectDuctsCommand : ExternalCommand { public override void Execute() => ActiveUiDocument.Selection.SetElementIds(MepHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_DuctCurves).Select(e => e.Id).ToList()); }
[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectConduitsCommand : ExternalCommand { public override void Execute() => ActiveUiDocument.Selection.SetElementIds(MepHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_Conduit).Select(e => e.Id).ToList()); }
[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectCableTraysCommand : ExternalCommand { public override void Execute() => ActiveUiDocument.Selection.SetElementIds(MepHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_CableTray).Select(e => e.Id).ToList()); }
[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectSpacesCommand : ExternalCommand { public override void Execute() => ActiveUiDocument.Selection.SetElementIds(MepHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_MEPSpaces).Select(e => e.Id).ToList()); }

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SystemReportCommand : ExternalCommand
{
    public override void Execute()
    {
        var items = MepHelpers.MepCurves(ActiveDocument);
        var rows = new List<string[]> { new[] { "Id", "Category", "System", "Type", "Level" } };
        foreach (var e in items)
        {
            rows.Add([e.Id.ToString(), e.Category?.Name ?? "", MepHelpers.SystemName(e), ActiveDocument.GetElement(e.GetTypeId())?.Name ?? "", ActiveDocument.GetElement(e.LevelId)?.Name ?? ""]);
        }
        var path = ReportService.WriteCsv("MEP_Systems", rows);
        TaskDialog.Show(ProductInfo.Name, $"Exported {items.Count} MEP curve(s).\n{path}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ExportMepCommand : ExternalCommand
{
    public override void Execute()
    {
        var items = MepHelpers.MepCurves(ActiveDocument).Concat(MepHelpers.MepFittings(ActiveDocument)).ToList();
        var path = ReportService.WriteCsv("MEP", ModelDataService.ElementRows(items));
        TaskDialog.Show(ProductInfo.Name, $"Exported {items.Count} MEP element(s).\n{path}");
    }
}
