using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Architecture;
using Autodesk.Revit.UI;
using Nice3point.Revit.Toolkit.External;
using AP.BimTools.Core;
using AP.BimTools.Core.Services;
using AP.BimTools.Core.UI;
using AP.BimTools.Core.Utilities;

namespace AP.BimTools.Architecture.Commands;

internal static class ArchHelpers
{
    public static List<Element> InstancesOf(Document doc, BuiltInCategory category) =>
        new FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType().ToElements().ToList();

    public static List<Room> Rooms(Document doc) =>
        new FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Rooms).WhereElementIsNotElementType().Cast<Room>().ToList();

    public static List<Room> SelectedRooms(UIDocument uiDoc)
    {
        var rooms = SelectionUtils.GetSelectedElements(uiDoc).OfType<Room>().ToList();
        return rooms.Count > 0 ? rooms : Rooms(uiDoc.Document).Where(r => r.Location is not null && r.Area > 0).ToList();
    }

    public static IList<CurveLoop>? RoomLoops(Room room)
    {
        var segments = room.GetBoundarySegments(new SpatialElementBoundaryOptions());
        if (segments is null || segments.Count == 0) return null;
        var loops = new List<CurveLoop>();
        foreach (var segmentLoop in segments)
        {
            var curves = segmentLoop.Select(s => s.GetCurve()).ToList();
            if (curves.Count >= 3) loops.Add(CurveLoop.Create(curves));
        }
        return loops.Count == 0 ? null : loops;
    }

    public static (string prefix, int start)? AskNumbering(string title, string defaultPrefix)
    {
        var prefix = PromptDialog.AskText(title, "Prefix:", defaultPrefix);
        if (prefix is null) return null;
        var startText = PromptDialog.AskText(title, "Start number:", "1");
        if (!int.TryParse(startText, out var start) || start < 0) return null;
        return (prefix, start);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class CreateFloorsFromRoomsCommand : ExternalCommand
{
    public override void Execute()
    {
        var rooms = ArchHelpers.SelectedRooms(ActiveUiDocument);
        if (rooms.Count == 0) { TaskDialog.Show(ProductInfo.Name, "No valid rooms found."); return; }
        var floorType = new FilteredElementCollector(ActiveDocument).OfClass(typeof(FloorType)).Cast<FloorType>().FirstOrDefault();
        if (floorType is null) { TaskDialog.Show(ProductInfo.Name, "No floor type found."); return; }
        if (!PromptDialog.Confirm(ProductInfo.Name, $"Create {rooms.Count} floor(s) using type '{floorType.Name}'?\nSelect rooms first to limit the operation; otherwise all placed rooms are used.")) return;
        var created = 0; var skipped = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Floors from rooms", () =>
        {
            foreach (var room in rooms)
            {
                var loops = ArchHelpers.RoomLoops(room);
                if (loops is null || room.LevelId == ElementId.InvalidElementId) { skipped++; continue; }
                try { Floor.Create(ActiveDocument, loops, floorType.Id, room.LevelId); created++; } catch { skipped++; }
            }
        });
        TaskDialog.Show(ProductInfo.Name, $"Created: {created}\nSkipped/failed: {skipped}\nFloor type: {floorType.Name}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class CreateCeilingsFromRoomsCommand : ExternalCommand
{
    public override void Execute()
    {
        var rooms = ArchHelpers.SelectedRooms(ActiveUiDocument);
        if (rooms.Count == 0) { TaskDialog.Show(ProductInfo.Name, "No valid rooms found."); return; }
        var type = new FilteredElementCollector(ActiveDocument).OfClass(typeof(CeilingType)).Cast<CeilingType>().FirstOrDefault();
        if (type is null) { TaskDialog.Show(ProductInfo.Name, "No ceiling type found."); return; }
        if (!PromptDialog.Confirm(ProductInfo.Name, $"Create {rooms.Count} ceiling(s) using type '{type.Name}'?")) return;
        var created = 0; var skipped = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Ceilings from rooms", () =>
        {
            foreach (var room in rooms)
            {
                var loops = ArchHelpers.RoomLoops(room);
                if (loops is null || room.LevelId == ElementId.InvalidElementId) { skipped++; continue; }
                try { Ceiling.Create(ActiveDocument, loops, type.Id, room.LevelId, null, 0.0); created++; } catch { skipped++; }
            }
        });
        TaskDialog.Show(ProductInfo.Name, $"Created: {created}\nSkipped/failed: {skipped}\nCeiling type: {type.Name}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class FlipDoorFacingCommand : ExternalCommand
{
    public override void Execute()
    {
        var doors = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<FamilyInstance>().Where(x => CategoryUtils.Is(x, BuiltInCategory.OST_Doors)).ToList();
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Flip door facing", () =>
        {
            foreach (var door in doors) { if (door.CanFlipFacing) { door.flipFacing(); changed++; } }
        });
        TaskDialog.Show(ProductInfo.Name, $"Flipped facing: {changed}/{doors.Count} door(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class FlipDoorHandCommand : ExternalCommand
{
    public override void Execute()
    {
        var doors = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<FamilyInstance>().Where(x => CategoryUtils.Is(x, BuiltInCategory.OST_Doors)).ToList();
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Flip door hand", () =>
        {
            foreach (var door in doors) { if (door.CanFlipHand) { door.flipHand(); changed++; } }
        });
        TaskDialog.Show(ProductInfo.Name, $"Flipped hand: {changed}/{doors.Count} door(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class AllowWallJoinCommand : ExternalCommand
{
    public override void Execute()
    {
        var walls = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Wall>().ToList();
        TransactionUtils.Run(ActiveDocument, "AP - Allow wall joins", () =>
        {
            foreach (var wall in walls) { WallUtils.AllowWallJoinAtEnd(wall, 0); WallUtils.AllowWallJoinAtEnd(wall, 1); }
        });
        TaskDialog.Show(ProductInfo.Name, $"Enabled joins for {walls.Count} wall(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class DisallowWallJoinCommand : ExternalCommand
{
    public override void Execute()
    {
        var walls = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Wall>().ToList();
        TransactionUtils.Run(ActiveDocument, "AP - Disallow wall joins", () =>
        {
            foreach (var wall in walls) { WallUtils.DisallowWallJoinAtEnd(wall, 0); WallUtils.DisallowWallJoinAtEnd(wall, 1); }
        });
        TaskDialog.Show(ProductInfo.Name, $"Disabled joins for {walls.Count} wall(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RoomAuditCommand : ExternalCommand
{
    public override void Execute()
    {
        var rooms = ArchHelpers.Rooms(ActiveDocument);
        var unplaced = rooms.Count(r => r.Location is null);
        var zeroArea = rooms.Count(r => r.Location is not null && r.Area <= 0);
        var valid = rooms.Count - unplaced - zeroArea;
        var duplicateNumbers = rooms.Where(r => !string.IsNullOrWhiteSpace(r.Number)).GroupBy(r => r.Number).Count(g => g.Count() > 1);
        TaskDialog.Show(ProductInfo.Name, $"Rooms: {rooms.Count}\nValid placed rooms: {valid}\nUnplaced: {unplaced}\nNot enclosed / zero area: {zeroArea}\nDuplicate room numbers: {duplicateNumbers}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RenumberRoomsCommand : ExternalCommand
{
    public override void Execute()
    {
        var rooms = ArchHelpers.SelectedRooms(ActiveUiDocument);
        var input = ArchHelpers.AskNumbering("AP - Number Rooms", "R-");
        if (input is null) return;
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Renumber rooms", () => changed = RenumberService.Renumber(ActiveDocument, rooms, BuiltInParameter.ROOM_NUMBER, input.Value.prefix, input.Value.start, 3));
        TaskDialog.Show(ProductInfo.Name, $"Renumbered {changed} room(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RenumberDoorsCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument).Where(e => CategoryUtils.Is(e, BuiltInCategory.OST_Doors)).ToList();
        var doors = selected.Count > 0 ? selected : ArchHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_Doors);
        var input = ArchHelpers.AskNumbering("AP - Number Doors", "D-"); if (input is null) return;
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Renumber doors", () => changed = RenumberService.Renumber(ActiveDocument, doors, BuiltInParameter.ALL_MODEL_MARK, input.Value.prefix, input.Value.start, 3));
        TaskDialog.Show(ProductInfo.Name, $"Renumbered {changed} door(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RenumberWindowsCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument).Where(e => CategoryUtils.Is(e, BuiltInCategory.OST_Windows)).ToList();
        var windows = selected.Count > 0 ? selected : ArchHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_Windows);
        var input = ArchHelpers.AskNumbering("AP - Number Windows", "W-"); if (input is null) return;
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Renumber windows", () => changed = RenumberService.Renumber(ActiveDocument, windows, BuiltInParameter.ALL_MODEL_MARK, input.Value.prefix, input.Value.start, 3));
        TaskDialog.Show(ProductInfo.Name, $"Renumbered {changed} window(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ExportRoomsCommand : ExternalCommand
{
    public override void Execute()
    {
        var rooms = ArchHelpers.Rooms(ActiveDocument);
        var rows = new List<string[]> { new[] { "Id", "Number", "Name", "Level", "Area_m2", "Department" } };
        foreach (var room in rooms)
        {
            var level = ActiveDocument.GetElement(room.LevelId)?.Name ?? "";
            var area = UnitUtils.ConvertFromInternalUnits(room.Area, UnitTypeId.SquareMeters);
            var dept = room.get_Parameter(BuiltInParameter.ROOM_DEPARTMENT)?.AsString() ?? "";
            rows.Add([room.Id.ToString(), room.Number, room.Name, level, area.ToString("0.###"), dept]);
        }
        var path = ReportService.WriteCsv("Rooms", rows);
        TaskDialog.Show(ProductInfo.Name, $"Exported {rooms.Count} room(s).\n{path}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectRoomsCommand : ExternalCommand
{
    public override void Execute() => ActiveUiDocument.Selection.SetElementIds(ArchHelpers.Rooms(ActiveDocument).Select(r => r.Id).ToList());
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectDoorsCommand : ExternalCommand
{
    public override void Execute() => ActiveUiDocument.Selection.SetElementIds(ArchHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_Doors).Select(e => e.Id).ToList());
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectWindowsCommand : ExternalCommand
{
    public override void Execute() => ActiveUiDocument.Selection.SetElementIds(ArchHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_Windows).Select(e => e.Id).ToList());
}
