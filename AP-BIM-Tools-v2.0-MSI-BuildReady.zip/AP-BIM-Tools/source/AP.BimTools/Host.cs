using Microsoft.Extensions.Hosting;
using Serilog;
using AP.BimTools.Core.Services;

namespace AP.BimTools;

public static class Host
{
    private static IHost? _host;

    public static async Task StartAsync()
    {
        var logDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AP", "AP-BIM Tools", "Logs");
        Directory.CreateDirectory(logDir);
        Log.Logger = new LoggerConfiguration()
            .MinimumLevel.Information()
            .WriteTo.File(Path.Combine(logDir, "ap-bim-.log"), rollingInterval: RollingInterval.Day, retainedFileCountLimit: 14)
            .CreateLogger();

        var builder = new HostApplicationBuilder(new HostApplicationBuilderSettings { DisableDefaults = true });
        _host = builder.Build();
        await _host.StartAsync();
        Log.Information("AP-BIM Tools started");
    }

    public static async Task StopAsync()
    {
        if (_host is not null) await _host.StopAsync();
        Log.CloseAndFlush();
    }
}
