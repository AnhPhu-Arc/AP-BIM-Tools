using Autodesk.Revit.UI;
using Nice3point.Revit.Extensions.UI;
using Nice3point.Revit.Toolkit.External;
using AP.BimTools.Core;
using AP.BimTools.Architecture.Commands;
using AP.BimTools.Structure.Commands;
using AP.BimTools.Mep.Commands;
using AP.BimTools.General.Commands;

namespace AP.BimTools;

[UsedImplicitly]
public class Application : AsyncExternalApplication
{
    private const string Icon16 = "/AP.BimTools;component/RibbonIcon16.png";
    private const string Icon32 = "/AP.BimTools;component/RibbonIcon32.png";

    public override async Task OnStartupAsync()
    {
        await Host.StartAsync();
        CreateArchitectureRibbon();
        CreateStructureRibbon();
        CreateMepRibbon();
        CreateGeneralRibbon();
    }

    public override async Task OnShutdownAsync() => await Host.StopAsync();

    private void CreateArchitectureRibbon()
    {
        var model = Application.CreatePanel("Model", ProductInfo.ArchitectureTab);
        Add<CreateFloorsFromRoomsCommand>(model, "Room →\nFloor", "Create floors from selected room boundaries.");
        Add<CreateCeilingsFromRoomsCommand>(model, "Room →\nCeiling", "Create ceilings from selected room boundaries.");
        Add<FlipDoorFacingCommand>(model, "Flip Door\nFacing", "Flip facing of selected door instances.");
        Add<FlipDoorHandCommand>(model, "Flip Door\nHand", "Flip hand of selected door instances.");
        Add<AllowWallJoinCommand>(model, "Allow Wall\nJoin", "Allow joins at both ends of selected walls.");
        Add<DisallowWallJoinCommand>(model, "Block Wall\nJoin", "Disallow joins at both ends of selected walls.");

        var data = Application.CreatePanel("Rooms & Marks", ProductInfo.ArchitectureTab);
        Add<RoomAuditCommand>(data, "Room\nAudit", "Check room placement, enclosure and area.");
        Add<RenumberRoomsCommand>(data, "Number\nRooms", "Renumber selected rooms by model position.");
        Add<RenumberDoorsCommand>(data, "Number\nDoors", "Renumber doors by model position.");
        Add<RenumberWindowsCommand>(data, "Number\nWindows", "Renumber windows by model position.");
        Add<ExportRoomsCommand>(data, "Export\nRooms", "Export room data to CSV.");

        var select = Application.CreatePanel("Selection", ProductInfo.ArchitectureTab);
        Add<SelectRoomsCommand>(select, "Select\nRooms", "Select rooms in the project.");
        Add<SelectDoorsCommand>(select, "Select\nDoors", "Select door instances.");
        Add<SelectWindowsCommand>(select, "Select\nWindows", "Select window instances.");
    }

    private void CreateStructureRibbon()
    {
        var model = Application.CreatePanel("Structure", ProductInfo.StructureTab);
        Add<AllowBeamJoinsCommand>(model, "Allow Beam\nJoin", "Allow joins at selected beam ends.");
        Add<DisallowBeamJoinsCommand>(model, "Block Beam\nJoin", "Disallow joins at selected beam ends.");
        Add<ZeroBeamOffsetsCommand>(model, "Zero Beam\nOffsets", "Set beam end elevation offsets to zero.");
        Add<JoinSelectedGeometryCommand>(model, "Join\nGeometry", "Join the first two selected elements.");

        var marks = Application.CreatePanel("Marks", ProductInfo.StructureTab);
        Add<RenumberColumnsCommand>(marks, "Number\nColumns", "Renumber structural columns.");
        Add<RenumberBeamsCommand>(marks, "Number\nBeams", "Renumber structural framing.");
        Add<RenumberFoundationsCommand>(marks, "Number\nFoundations", "Renumber structural foundations.");

        var rebar = Application.CreatePanel("AP-Rebar Studio", ProductInfo.StructureTab);
        Add<RebarStudioCommand>(rebar, "Rebar\nStudio", "Configure and reinforce mixed selected hosts: beam, column, wall, slab and foundation.");
        Add<BeamRebarAxisStudioCommand>(rebar, "Beam Rebar\nAxis", "Beam reinforcement by span/axis: top/bottom bars, support extras and three stirrup zones.");
        Add<ColumnRebarStudioCommand>(rebar, "Column\nRebar", "Column perimeter main bars and end/middle tie zones.");
        Add<WallRebarStudioCommand>(rebar, "Wall\nRebar", "Wall vertical/horizontal reinforcement on one or both faces plus boundary bars.");
        Add<SlabRebarStudioCommand>(rebar, "Slab\nRebar", "Create top/bottom X/Y slab reinforcement mats.");
        Add<FoundationRebarStudioCommand>(rebar, "Foundation\nRebar", "Create top/bottom X/Y reinforcement mats for supported structural foundations.");

        var rebarOps = Application.CreatePanel("Rebar Operations", ProductInfo.StructureTab);
        Add<ApplySavedRebarPresetCommand>(rebarOps, "Apply Saved\nPreset", "Apply the last AP-Rebar settings to selected supported hosts.");
        Add<ColumnStarterBarsCommand>(rebarOps, "Column →\nFoundation", "Create column starter bars into the nearest structural foundation below each selected column.");
        Add<DeleteHostedRebarCommand>(rebarOps, "Clear Host\nRebar", "Delete all Rebar hosted by selected supported concrete hosts.");
        Add<SetRebarSpacingCommand>(rebarOps, "Set Rebar\nSpacing", "Set Maximum Spacing layout for selected shape-driven rebar sets.");
        Add<RenumberRebarCommand>(rebarOps, "Number\nRebar", "Renumber selected rebar, or all rebar when nothing is selected.");
        Add<SelectRebarByHostCommand>(rebarOps, "Rebar by\nHost", "Select rebar hosted by the selected concrete elements.");
        Add<SelectApRebarCommand>(rebarOps, "Select AP\nRebar", "Select rebar generated by AP-Rebar based on AP metadata.");

        var rebarDocs = Application.CreatePanel("Rebar Documentation", ProductInfo.StructureTab);
        Add<ExportRebarBbsCommand>(rebarDocs, "Export\nBBS", "Export aggregated bar bending/quantity data and estimated steel mass to CSV.");
        Add<CreateRebarScheduleCommand>(rebarDocs, "Rebar\nSchedule", "Create a native Revit Rebar schedule with core quantity fields.");
        Add<CreateRebarReview3DCommand>(rebarDocs, "Rebar Review\n3D", "Create a cropped Fine-detail 3D review view around selected reinforced hosts.");
        Add<CreateRebarDetailSectionsCommand>(rebarDocs, "Rebar Detail\nSections", "Create cropped section views for selected reinforced hosts and show hosted rebar unobscured.");
        Add<RebarAuditDetailedCommand>(rebarDocs, "Rebar\nAudit", "Audit rebar host, mark, quantity and total length and export CSV.");
        Add<RebarReportCommand>(rebarDocs, "Rebar\nReport", "Export rebar properties and quantities.");
        Add<RebarSolidCommand>(rebarDocs, "Rebar\nSolid", "Show selected rebar solid in active 3D view.");
        Add<RebarUnobscuredCommand>(rebarDocs, "Rebar\nVisible", "Make selected rebar unobscured in active view.");

        var dimensions = Application.CreatePanel("Quick Dim", ProductInfo.StructureTab);
        Add<QuickDimGridCommand>(dimensions, "Dim\nGrid", "Create chained dimensions for visible straight grid groups in the active view.");
        Add<QuickDimLevelCommand>(dimensions, "Dim\nLevel", "Create chained dimensions for visible levels in section/elevation.");
        Add<QuickDimWallPlanCommand>(dimensions, "Dim Wall\nPlan", "Dimension both faces of selected straight walls by parallel groups.");
        Add<QuickDimPilePlanCommand>(dimensions, "Dim Pile\nPlan", "Dimension pile center references in two plan directions.");
        Add<QuickDimColumnPlanCommand>(dimensions, "Dim Column\nPlan", "Dimension structural column center references in two plan directions.");

        var qa = Application.CreatePanel("QA/QC", ProductInfo.StructureTab);
        Add<StructuralAuditCommand>(qa, "Structure\nAudit", "Audit structural model content.");
        Add<SelectStructuralColumnsCommand>(qa, "Select\nColumns", "Select structural columns.");
        Add<SelectFramingCommand>(qa, "Select\nFraming", "Select structural framing.");
        Add<SelectFoundationsCommand>(qa, "Select\nFoundations", "Select structural foundations.");
        Add<ExportStructureCommand>(qa, "Export\nStructure", "Export structural element data.");
    }

    private void CreateMepRibbon()
    {
        var connect = Application.CreatePanel("Connect", ProductInfo.MepTab);
        Add<ConnectTwoElementsCommand>(connect, "Connect\nNearest", "Connect the nearest open end connectors of two selected MEP elements.");
        Add<SetOffsetCommand>(connect, "Set\nOffset", "Set offset in millimetres for selected MEP curves.");

        var qa = Application.CreatePanel("QA/QC", ProductInfo.MepTab);
        Add<MepAuditCommand>(qa, "MEP\nAudit", "Audit MEP curves, fittings and open connectors.");
        Add<SelectOpenConnectorOwnersCommand>(qa, "Open\nConnectors", "Select elements that contain open end connectors.");
        Add<OpenConnectorReportCommand>(qa, "Connector\nReport", "Export open connectors to CSV.");
        Add<FittingAuditCommand>(qa, "Fitting\nAudit", "Find MEP fittings with unconnected ends.");
        Add<MepClashCommand>(qa, "Quick\nClash", "Bounding-box clash screen between MEP and architecture/structure.");
        Add<SpaceAuditCommand>(qa, "Space\nAudit", "Audit placed MEP spaces.");

        var select = Application.CreatePanel("Selection", ProductInfo.MepTab);
        Add<SelectPipesCommand>(select, "Select\nPipes", "Select all pipes.");
        Add<SelectDuctsCommand>(select, "Select\nDucts", "Select all ducts.");
        Add<SelectConduitsCommand>(select, "Select\nConduits", "Select all conduits.");
        Add<SelectCableTraysCommand>(select, "Select Cable\nTrays", "Select all cable trays.");
        Add<SelectSpacesCommand>(select, "Select\nSpaces", "Select all MEP spaces.");

        var data = Application.CreatePanel("Data", ProductInfo.MepTab);
        Add<SystemReportCommand>(data, "System\nReport", "Export MEP system/category data.");
        Add<ExportMepCommand>(data, "Export\nMEP", "Export MEP element data.");
    }

    private void CreateGeneralRibbon()
    {
        var qa = Application.CreatePanel("QA/QC", ProductInfo.GeneralTab);
        Add<ModelHealthCommand>(qa, "Model\nHealth", "Project health dashboard: warnings, imports, links, views and model content.");
        Add<WarningSummaryCommand>(qa, "Warning\nSummary", "Summarize Revit warnings.");
        Add<LinkReportCommand>(qa, "Link\nReport", "Report RVT links and statuses.");
        Add<CadImportReportCommand>(qa, "CAD\nReport", "Report imported and linked CAD instances.");
        Add<CoordinatesReportCommand>(qa, "Project\nCoordinates", "Report project location transform values.");

        var selection = Application.CreatePanel("Selection", ProductInfo.GeneralTab);
        Add<SelectSameCategoryCommand>(selection, "Same\nCategory", "Select all elements with the same category as a seed element.");
        Add<SelectSameTypeCommand>(selection, "Same\nType", "Select all elements of the same Revit type as a seed element.");
        Add<PinSelectedCommand>(selection, "Pin", "Pin selected elements where supported.");
        Add<UnpinSelectedCommand>(selection, "Unpin", "Unpin selected elements where supported.");
        Add<IsolateSelectedCommand>(selection, "Isolate", "Temporarily isolate selected elements.");
        Add<ResetTempViewCommand>(selection, "Reset Temp\nView", "Reset temporary hide/isolate.");

        var docs = Application.CreatePanel("Documentation", ProductInfo.GeneralTab);
        Add<PrefixViewsCommand>(docs, "Prefix\nViews", "Add a prefix to selected views.");
        Add<PrefixSheetsCommand>(docs, "Prefix\nSheets", "Add a prefix to selected sheets.");
        Add<ExportSelectionCommand>(docs, "Export\nSelection", "Export selected element data to CSV.");

        var tools = Application.CreatePanel("Tools", ProductInfo.GeneralTab);
        Add<PurgeUnusedCommand>(tools, "Purge\nUnused", "Open Revit Purge Unused command.");
        Add<AboutCommand>(tools, "About\nAP", "About AP-BIM Tools.");
    }

    private static void Add<T>(RibbonPanel panel, string text, string tooltip) where T : ExternalCommand, new()
    {
        var button = panel.AddPushButton<T>(text)
            .SetImage(Icon16)
            .SetLargeImage(Icon32);
        button.ToolTip = tooltip;
    }
}
