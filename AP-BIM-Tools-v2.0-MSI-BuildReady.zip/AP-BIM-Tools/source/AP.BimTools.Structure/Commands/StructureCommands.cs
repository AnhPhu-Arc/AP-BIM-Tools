using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Nice3point.Revit.Toolkit.External;
using AP.BimTools.Core;
using AP.BimTools.Core.Services;
using AP.BimTools.Core.UI;
using AP.BimTools.Core.Utilities;

namespace AP.BimTools.Structure.Commands;

internal static class StrHelpers
{
    public static List<Element> InstancesOf(Document doc, BuiltInCategory category) =>
        new FilteredElementCollector(doc).OfCategory(category).WhereElementIsNotElementType().ToElements().ToList();

    public static List<Element> SelectedOrAll(UIDocument uiDoc, BuiltInCategory category)
    {
        var selected = SelectionUtils.GetSelectedElements(uiDoc).Where(e => CategoryUtils.Is(e, category)).ToList();
        return selected.Count > 0 ? selected : InstancesOf(uiDoc.Document, category);
    }

    public static (string prefix, int start)? AskNumbering(string title, string prefix)
    {
        var p = PromptDialog.AskText(title, "Prefix:", prefix); if (p is null) return null;
        var s = PromptDialog.AskText(title, "Start number:", "1");
        return int.TryParse(s, out var start) ? (p, start) : null;
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class AllowBeamJoinsCommand : ExternalCommand
{
    public override void Execute()
    {
        var beams = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<FamilyInstance>()
            .Where(e => CategoryUtils.Is(e, BuiltInCategory.OST_StructuralFraming)).ToList();
        TransactionUtils.Run(ActiveDocument, "AP - Allow beam joins", () =>
        {
            foreach (var beam in beams) { StructuralFramingUtils.AllowJoinAtEnd(beam, 0); StructuralFramingUtils.AllowJoinAtEnd(beam, 1); }
        });
        TaskDialog.Show(ProductInfo.Name, $"Enabled joins for {beams.Count} framing element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class DisallowBeamJoinsCommand : ExternalCommand
{
    public override void Execute()
    {
        var beams = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<FamilyInstance>()
            .Where(e => CategoryUtils.Is(e, BuiltInCategory.OST_StructuralFraming)).ToList();
        TransactionUtils.Run(ActiveDocument, "AP - Disallow beam joins", () =>
        {
            foreach (var beam in beams) { StructuralFramingUtils.DisallowJoinAtEnd(beam, 0); StructuralFramingUtils.DisallowJoinAtEnd(beam, 1); }
        });
        TaskDialog.Show(ProductInfo.Name, $"Disabled joins for {beams.Count} framing element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ZeroBeamOffsetsCommand : ExternalCommand
{
    public override void Execute()
    {
        var beams = SelectionUtils.GetSelectedElements(ActiveUiDocument).Where(e => CategoryUtils.Is(e, BuiltInCategory.OST_StructuralFraming)).ToList();
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Zero beam offsets", () =>
        {
            foreach (var beam in beams)
            {
                foreach (var bip in new[] { BuiltInParameter.STRUCTURAL_BEAM_END0_ELEVATION, BuiltInParameter.STRUCTURAL_BEAM_END1_ELEVATION })
                {
                    var p = beam.get_Parameter(bip);
                    if (p is null || p.IsReadOnly || p.StorageType != StorageType.Double) continue;
                    try { p.Set(0.0); changed++; } catch { }
                }
            }
        });
        TaskDialog.Show(ProductInfo.Name, $"Reset {changed} beam end offset value(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class JoinSelectedGeometryCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument);
        if (selected.Count != 2) { TaskDialog.Show(ProductInfo.Name, "Select exactly two elements."); return; }
        if (JoinGeometryUtils.AreElementsJoined(ActiveDocument, selected[0], selected[1])) { TaskDialog.Show(ProductInfo.Name, "The two elements are already joined."); return; }
        TransactionUtils.Run(ActiveDocument, "AP - Join geometry", () => JoinGeometryUtils.JoinGeometry(ActiveDocument, selected[0], selected[1]));
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RenumberColumnsCommand : ExternalCommand
{
    public override void Execute()
    {
        var items = StrHelpers.SelectedOrAll(ActiveUiDocument, BuiltInCategory.OST_StructuralColumns);
        var input = StrHelpers.AskNumbering("AP - Number Columns", "C-"); if (input is null) return;
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Number columns", () => changed = RenumberService.Renumber(ActiveDocument, items, BuiltInParameter.ALL_MODEL_MARK, input.Value.prefix, input.Value.start, 3));
        TaskDialog.Show(ProductInfo.Name, $"Renumbered {changed} column(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RenumberBeamsCommand : ExternalCommand
{
    public override void Execute()
    {
        var items = StrHelpers.SelectedOrAll(ActiveUiDocument, BuiltInCategory.OST_StructuralFraming);
        var input = StrHelpers.AskNumbering("AP - Number Beams", "B-"); if (input is null) return;
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Number beams", () => changed = RenumberService.Renumber(ActiveDocument, items, BuiltInParameter.ALL_MODEL_MARK, input.Value.prefix, input.Value.start, 3));
        TaskDialog.Show(ProductInfo.Name, $"Renumbered {changed} framing element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RenumberFoundationsCommand : ExternalCommand
{
    public override void Execute()
    {
        var items = StrHelpers.SelectedOrAll(ActiveUiDocument, BuiltInCategory.OST_StructuralFoundation);
        var input = StrHelpers.AskNumbering("AP - Number Foundations", "F-"); if (input is null) return;
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Number foundations", () => changed = RenumberService.Renumber(ActiveDocument, items, BuiltInParameter.ALL_MODEL_MARK, input.Value.prefix, input.Value.start, 3));
        TaskDialog.Show(ProductInfo.Name, $"Renumbered {changed} foundation element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class StructuralAuditCommand : ExternalCommand
{
    public override void Execute()
    {
        var columns = StrHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_StructuralColumns);
        var framing = StrHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_StructuralFraming);
        var foundations = StrHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_StructuralFoundation);
        var rebars = new FilteredElementCollector(ActiveDocument).OfClass(typeof(Rebar)).Cast<Rebar>().ToList();
        var items = columns.Concat(framing).Concat(foundations).ToList();
        var blankMarks = items.Count(e => string.IsNullOrWhiteSpace(e.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString()));
        var duplicateMarks = items.Select(e => e.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString())
            .Where(s => !string.IsNullOrWhiteSpace(s)).GroupBy(s => s).Count(g => g.Count() > 1);
        TaskDialog.Show(ProductInfo.Name, $"Structural columns: {columns.Count}\nFraming: {framing.Count}\nFoundations: {foundations.Count}\nRebar: {rebars.Count}\nBlank marks: {blankMarks}\nDuplicate marks: {duplicateMarks}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RebarReportCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Rebar>().ToList();
        var rebars = selected.Count > 0 ? selected : new FilteredElementCollector(ActiveDocument).OfClass(typeof(Rebar)).Cast<Rebar>().ToList();
        var rows = new List<string[]> { new[] { "Id", "Mark", "Type", "Quantity", "TotalLength_m", "HostId" } };
        foreach (var rebar in rebars)
        {
            var mark = rebar.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString() ?? "";
            var type = ActiveDocument.GetElement(rebar.GetTypeId())?.Name ?? "";
            var qty = rebar.get_Parameter(BuiltInParameter.REBAR_ELEM_QUANTITY_OF_BARS)?.AsInteger().ToString() ?? "";
            var total = rebar.get_Parameter(BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH)?.AsDouble() ?? 0;
            var meters = UnitUtils.ConvertFromInternalUnits(total, UnitTypeId.Meters);
            rows.Add([rebar.Id.ToString(), mark, type, qty, meters.ToString("0.###"), rebar.GetHostId().ToString()]);
        }
        var path = ReportService.WriteCsv("Rebar", rows);
        TaskDialog.Show(ProductInfo.Name, $"Exported {rebars.Count} rebar element(s).\n{path}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RebarSolidCommand : ExternalCommand
{
    public override void Execute()
    {
        if (ActiveDocument.ActiveView is not View3D view3D) { TaskDialog.Show(ProductInfo.Name, "Activate a 3D view first."); return; }
        var rebars = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Rebar>().ToList();
        if (rebars.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select rebar elements first."); return; }
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Rebar solid view", () =>
        {
            view3D.DetailLevel = ViewDetailLevel.Fine;
            foreach (var rebar in rebars) { try { rebar.SetUnobscuredInView(view3D, true); changed++; } catch { } }
        });
        TaskDialog.Show(ProductInfo.Name, $"3D detail level set to Fine; {changed} selected rebar element(s) set unobscured. Modern Revit renders rebar solid automatically in Fine detail level.");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RebarUnobscuredCommand : ExternalCommand
{
    public override void Execute()
    {
        var rebars = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Rebar>().ToList();
        if (rebars.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select rebar elements first."); return; }
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Rebar unobscured", () =>
        {
            foreach (var rebar in rebars) { try { rebar.SetUnobscuredInView(ActiveDocument.ActiveView, true); changed++; } catch { } }
        });
        TaskDialog.Show(ProductInfo.Name, $"Set unobscured display for {changed} rebar element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectStructuralColumnsCommand : ExternalCommand
{
    public override void Execute() => ActiveUiDocument.Selection.SetElementIds(StrHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_StructuralColumns).Select(e => e.Id).ToList());
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectFramingCommand : ExternalCommand
{
    public override void Execute() => ActiveUiDocument.Selection.SetElementIds(StrHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_StructuralFraming).Select(e => e.Id).ToList());
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectFoundationsCommand : ExternalCommand
{
    public override void Execute() => ActiveUiDocument.Selection.SetElementIds(StrHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_StructuralFoundation).Select(e => e.Id).ToList());
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ExportStructureCommand : ExternalCommand
{
    public override void Execute()
    {
        var items = StrHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_StructuralColumns)
            .Concat(StrHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_StructuralFraming))
            .Concat(StrHelpers.InstancesOf(ActiveDocument, BuiltInCategory.OST_StructuralFoundation)).ToList();
        var path = ReportService.WriteCsv("Structure", ModelDataService.ElementRows(items));
        TaskDialog.Show(ProductInfo.Name, $"Exported {items.Count} structural element(s).\n{path}");
    }
}
