using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Nice3point.Revit.Toolkit.External;
using AP.BimTools.Core;
using AP.BimTools.Core.Services;
using AP.BimTools.Core.UI;
using AP.BimTools.Core.Utilities;

namespace AP.BimTools.Structure.Commands;

internal static class RebarCommandHelpers
{
    public static List<FamilyInstance> SelectedFamilyInstances(UIDocument uiDoc, BuiltInCategory category) =>
        SelectionUtils.GetSelectedElements(uiDoc).OfType<FamilyInstance>().Where(x => CategoryUtils.Is(x, category)).ToList();

    public static List<Rebar> SelectedOrAllRebar(UIDocument uiDoc)
    {
        var selected = SelectionUtils.GetSelectedElements(uiDoc).OfType<Rebar>().ToList();
        return selected.Count > 0
            ? selected
            : new FilteredElementCollector(uiDoc.Document).OfClass(typeof(Rebar)).Cast<Rebar>().ToList();
    }

    public static RebarBarType? AskBarType(Document doc, string title, double defaultDiameter)
    {
        var diameter = PromptDialog.AskDouble(title, "Nominal bar diameter (mm):", defaultDiameter);
        if (diameter is null || diameter <= 0) return null;
        var type = RebarModelingService.FindClosestBarType(doc, diameter.Value);
        if (type is null) TaskDialog.Show(ProductInfo.Name, "No Rebar Bar Type exists in this project. Load/create rebar bar types first.");
        return type;
    }

    public static void ShowCreateResult(RebarModelingService.CreateResult result, RebarBarType type)
    {
        var dia = UnitUtils.ConvertFromInternalUnits(type.BarNominalDiameter, UnitTypeId.Millimeters);
        TaskDialog.Show(ProductInfo.Name,
            $"Created: {result.Created}\nSkipped/unsupported hosts: {result.Skipped}\nBar type: {type.Name} (≈ {dia:0.#} mm)" +
            (string.IsNullOrWhiteSpace(result.Note) ? "" : $"\n\n{result.Note}"));
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class BeamLongitudinalRebarCommand : ExternalCommand
{
    public override void Execute()
    {
        var beams = RebarCommandHelpers.SelectedFamilyInstances(ActiveUiDocument, BuiltInCategory.OST_StructuralFraming);
        if (beams.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select one or more structural beams first."); return; }
        var type = RebarCommandHelpers.AskBarType(ActiveDocument, "AP - Beam 4 Bars", 20); if (type is null) return;
        var cover = PromptDialog.AskDouble("AP - Beam 4 Bars", "Concrete cover (mm):", 30); if (cover is null || cover <= 0) return;
        RebarModelingService.CreateResult result = new(0, 0);
        TransactionUtils.Run(ActiveDocument, "AP - Beam 4 Bars", () => result = RebarModelingService.CreateBeamLongitudinal(ActiveDocument, beams, type, cover.Value));
        RebarCommandHelpers.ShowCreateResult(result, type);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class BeamStirrupsCommand : ExternalCommand
{
    public override void Execute()
    {
        var beams = RebarCommandHelpers.SelectedFamilyInstances(ActiveUiDocument, BuiltInCategory.OST_StructuralFraming);
        if (beams.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select one or more structural beams first."); return; }
        var type = RebarCommandHelpers.AskBarType(ActiveDocument, "AP - Beam Stirrups", 8); if (type is null) return;
        var cover = PromptDialog.AskDouble("AP - Beam Stirrups", "Concrete cover (mm):", 25); if (cover is null || cover <= 0) return;
        var spacing = PromptDialog.AskDouble("AP - Beam Stirrups", "Maximum spacing (mm):", 150); if (spacing is null || spacing <= 0) return;
        RebarModelingService.CreateResult result = new(0, 0);
        TransactionUtils.Run(ActiveDocument, "AP - Beam Stirrups", () => result = RebarModelingService.CreateBeamStirrups(ActiveDocument, beams, type, cover.Value, spacing.Value));
        RebarCommandHelpers.ShowCreateResult(result, type);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ColumnLongitudinalRebarCommand : ExternalCommand
{
    public override void Execute()
    {
        var columns = RebarCommandHelpers.SelectedFamilyInstances(ActiveUiDocument, BuiltInCategory.OST_StructuralColumns);
        if (columns.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select one or more structural columns first."); return; }
        var type = RebarCommandHelpers.AskBarType(ActiveDocument, "AP - Column 4 Bars", 20); if (type is null) return;
        var cover = PromptDialog.AskDouble("AP - Column 4 Bars", "Concrete cover (mm):", 30); if (cover is null || cover <= 0) return;
        RebarModelingService.CreateResult result = new(0, 0);
        TransactionUtils.Run(ActiveDocument, "AP - Column 4 Bars", () => result = RebarModelingService.CreateColumnLongitudinal(ActiveDocument, columns, type, cover.Value));
        RebarCommandHelpers.ShowCreateResult(result, type);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ColumnTiesCommand : ExternalCommand
{
    public override void Execute()
    {
        var columns = RebarCommandHelpers.SelectedFamilyInstances(ActiveUiDocument, BuiltInCategory.OST_StructuralColumns);
        if (columns.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select one or more structural columns first."); return; }
        var type = RebarCommandHelpers.AskBarType(ActiveDocument, "AP - Column Ties", 8); if (type is null) return;
        var cover = PromptDialog.AskDouble("AP - Column Ties", "Concrete cover (mm):", 25); if (cover is null || cover <= 0) return;
        var spacing = PromptDialog.AskDouble("AP - Column Ties", "Maximum spacing (mm):", 150); if (spacing is null || spacing <= 0) return;
        RebarModelingService.CreateResult result = new(0, 0);
        TransactionUtils.Run(ActiveDocument, "AP - Column Ties", () => result = RebarModelingService.CreateColumnTies(ActiveDocument, columns, type, cover.Value, spacing.Value));
        RebarCommandHelpers.ShowCreateResult(result, type);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SetRebarSpacingCommand : ExternalCommand
{
    public override void Execute()
    {
        var rebars = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Rebar>().ToList();
        if (rebars.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select one or more shape-driven rebar sets first."); return; }
        var spacingMm = PromptDialog.AskDouble("AP - Set Rebar Spacing", "Maximum spacing (mm):", 150); if (spacingMm is null || spacingMm <= 0) return;
        var spacing = UnitUtils.ConvertToInternalUnits(spacingMm.Value, UnitTypeId.Millimeters);
        var changed = 0;
        var skipped = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Set Rebar Spacing", () =>
        {
            foreach (var rebar in rebars)
            {
                try
                {
                    using var accessor = rebar.GetShapeDrivenAccessor();
                    var length = accessor.ArrayLength;
                    var side = accessor.BarsOnNormalSide;
                    accessor.SetLayoutAsMaximumSpacing(spacing, length, side, true, true);
                    changed++;
                }
                catch { skipped++; }
            }
        });
        TaskDialog.Show(ProductInfo.Name, $"Updated {changed} rebar set(s).\nSkipped: {skipped}.");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RenumberRebarCommand : ExternalCommand
{
    public override void Execute()
    {
        var rebars = RebarCommandHelpers.SelectedOrAllRebar(ActiveUiDocument).Cast<Element>().ToList();
        if (rebars.Count == 0) { TaskDialog.Show(ProductInfo.Name, "No rebar found."); return; }
        var prefix = PromptDialog.AskText("AP - Number Rebar", "Prefix:", "RB-"); if (prefix is null) return;
        var startText = PromptDialog.AskText("AP - Number Rebar", "Start number:", "1");
        if (!int.TryParse(startText, out var start)) return;
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Number Rebar", () => changed = RenumberService.Renumber(ActiveDocument, rebars, BuiltInParameter.ALL_MODEL_MARK, prefix, start, 3));
        TaskDialog.Show(ProductInfo.Name, $"Renumbered {changed} rebar element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectRebarByHostCommand : ExternalCommand
{
    public override void Execute()
    {
        var hosts = SelectionUtils.GetSelectedElements(ActiveUiDocument).Where(e => e is not Rebar).Select(e => e.Id).ToList();
        if (hosts.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select one or more concrete host elements first."); return; }
        var rebars = new FilteredElementCollector(ActiveDocument).OfClass(typeof(Rebar)).Cast<Rebar>()
            .Where(r => hosts.Contains(r.GetHostId())).Select(r => r.Id).ToList();
        ActiveUiDocument.Selection.SetElementIds(rebars);
        TaskDialog.Show(ProductInfo.Name, $"Selected {rebars.Count} rebar element(s) hosted by the selected elements.");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RebarAuditDetailedCommand : ExternalCommand
{
    public override void Execute()
    {
        var rebars = RebarCommandHelpers.SelectedOrAllRebar(ActiveUiDocument);
        if (rebars.Count == 0) { TaskDialog.Show(ProductInfo.Name, "No rebar found."); return; }
        var noHost = 0; var blankMark = 0; var zeroQty = 0; var zeroLength = 0;
        var rows = new List<string[]> { new[] { "Id", "Mark", "Type", "HostId", "Qty", "TotalLength_m", "Issues" } };
        foreach (var r in rebars)
        {
            var issues = new List<string>();
            var host = r.GetHostId();
            if (host == ElementId.InvalidElementId) { noHost++; issues.Add("No host"); }
            var mark = r.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString() ?? "";
            if (string.IsNullOrWhiteSpace(mark)) { blankMark++; issues.Add("Blank mark"); }
            var qty = r.get_Parameter(BuiltInParameter.REBAR_ELEM_QUANTITY_OF_BARS)?.AsInteger() ?? 0;
            if (qty <= 0) { zeroQty++; issues.Add("Qty <= 0"); }
            var len = r.get_Parameter(BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH)?.AsDouble() ?? 0;
            if (len <= 1e-9) { zeroLength++; issues.Add("Zero length"); }
            var meters = UnitUtils.ConvertFromInternalUnits(len, UnitTypeId.Meters);
            rows.Add([r.Id.ToString(), mark, ActiveDocument.GetElement(r.GetTypeId())?.Name ?? "", host.ToString(), qty.ToString(), meters.ToString("0.###"), string.Join("; ", issues)]);
        }
        var path = ReportService.WriteCsv("RebarAudit", rows);
        TaskDialog.Show(ProductInfo.Name,
            $"Rebar checked: {rebars.Count}\nNo host: {noHost}\nBlank mark: {blankMark}\nQty <= 0: {zeroQty}\nZero length: {zeroLength}\n\nCSV: {path}");
    }
}
