using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using Autodesk.Revit.UI;
using Nice3point.Revit.Toolkit.External;
using AP.BimTools.Core;
using AP.BimTools.Core.Services;
using AP.BimTools.Core.UI;
using AP.BimTools.Core.Utilities;
using AP.BimTools.Structure.RebarStudio;

namespace AP.BimTools.Structure.Commands;

internal static class RebarStudioCommandRunner
{
    public static void Run(UIDocument uiDoc, Document doc, RebarStudioMode mode)
    {
        var hosts = SelectionUtils.GetSelectedElements(uiDoc)
            .Where(RebarEngineService.IsSupportedHost)
            .Where(x => mode == RebarStudioMode.Auto || RebarEngineService.ModeForHost(x) == mode)
            .ToList();

        if (hosts.Count == 0)
        {
            TaskDialog.Show(ProductInfo.Name, mode == RebarStudioMode.Auto
                ? "Select one or more supported concrete hosts first: beam, column, wall, floor/slab or structural foundation."
                : $"Select one or more {mode} host(s) first.");
            return;
        }

        var options = RebarStudioSettingsStore.Load();
        options.Mode = mode;
        var window = new RebarStudioWindow(options, mode, hosts.Count);
        if (window.ShowDialog() != true) return;
        options = window.Options;
        options.Mode = mode;

        RebarEngineResult result = RebarEngineResult.Empty;
        TransactionUtils.Run(doc, $"AP-Rebar {mode}", () => result = RebarEngineService.Apply(doc, hosts, options));
        RebarStudioSettingsStore.Save(options);
        ShowResult(result, options);
    }

    public static void ApplySaved(UIDocument uiDoc, Document doc)
    {
        var hosts = SelectionUtils.GetSelectedElements(uiDoc).Where(RebarEngineService.IsSupportedHost).ToList();
        if (hosts.Count == 0)
        {
            TaskDialog.Show(ProductInfo.Name, "Select supported rebar hosts first.");
            return;
        }
        var options = RebarStudioSettingsStore.Load();
        options.Mode = RebarStudioMode.Auto;
        RebarEngineResult result = RebarEngineResult.Empty;
        TransactionUtils.Run(doc, "AP-Rebar Apply Saved", () => result = RebarEngineService.Apply(doc, hosts, options));
        ShowResult(result, options);
    }

    private static void ShowResult(RebarEngineResult result, RebarStudioOptions options)
    {
        var notes = result.Notes.Count == 0 ? "" : "\n\nNotes:\n" + string.Join("\n", result.Notes.Take(8));
        TaskDialog.Show(ProductInfo.Name,
            $"AP-Rebar completed.\n\nHosts reinforced: {result.HostsProcessed}\nHosts skipped: {result.HostsSkipped}\nRebar elements created: {result.RebarElementsCreated}\nOld hosted rebar deleted: {result.RebarElementsDeleted}\nPreset: {options.PresetName}" + notes);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class RebarStudioCommand : ExternalCommand
{
    public override void Execute() => RebarStudioCommandRunner.Run(ActiveUiDocument, ActiveDocument, RebarStudioMode.Auto);
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class BeamRebarAxisStudioCommand : ExternalCommand
{
    public override void Execute() => RebarStudioCommandRunner.Run(ActiveUiDocument, ActiveDocument, RebarStudioMode.Beam);
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ColumnRebarStudioCommand : ExternalCommand
{
    public override void Execute() => RebarStudioCommandRunner.Run(ActiveUiDocument, ActiveDocument, RebarStudioMode.Column);
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class WallRebarStudioCommand : ExternalCommand
{
    public override void Execute() => RebarStudioCommandRunner.Run(ActiveUiDocument, ActiveDocument, RebarStudioMode.Wall);
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SlabRebarStudioCommand : ExternalCommand
{
    public override void Execute() => RebarStudioCommandRunner.Run(ActiveUiDocument, ActiveDocument, RebarStudioMode.Slab);
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class FoundationRebarStudioCommand : ExternalCommand
{
    public override void Execute() => RebarStudioCommandRunner.Run(ActiveUiDocument, ActiveDocument, RebarStudioMode.Foundation);
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ApplySavedRebarPresetCommand : ExternalCommand
{
    public override void Execute() => RebarStudioCommandRunner.ApplySaved(ActiveUiDocument, ActiveDocument);
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class DeleteHostedRebarCommand : ExternalCommand
{
    public override void Execute()
    {
        var hosts = SelectionUtils.GetSelectedElements(ActiveUiDocument).Where(RebarEngineService.IsSupportedHost).ToList();
        if (hosts.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select supported rebar hosts first."); return; }
        if (!PromptDialog.Confirm("AP-Rebar", $"Delete all Rebar hosted by {hosts.Count} selected host(s)?")) return;
        var deleted = 0;
        TransactionUtils.Run(ActiveDocument, "AP-Rebar Clear Hosts", () => deleted = RebarEngineService.DeleteHostedRebar(ActiveDocument, hosts.Select(x => x.Id)));
        TaskDialog.Show(ProductInfo.Name, $"Deleted {deleted} hosted Rebar element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ColumnStarterBarsCommand : ExternalCommand
{
    public override void Execute()
    {
        var columns = SelectionUtils.GetSelectedElements(ActiveUiDocument)
            .OfType<FamilyInstance>()
            .Where(x => CategoryUtils.Is(x, BuiltInCategory.OST_StructuralColumns))
            .ToList();
        if (columns.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select one or more structural columns first."); return; }
        var options = RebarStudioSettingsStore.Load();
        var window = new RebarStudioWindow(options, RebarStudioMode.Column, columns.Count);
        if (window.ShowDialog() != true) return;
        options = window.Options;
        RebarEngineResult result = RebarEngineResult.Empty;
        TransactionUtils.Run(ActiveDocument, "AP-Rebar Column Starters", () => result = RebarEngineService.CreateColumnStarters(ActiveDocument, columns, options));
        RebarStudioSettingsStore.Save(options);
        var notes = result.Notes.Count == 0 ? "" : "\n\n" + string.Join("\n", result.Notes.Take(8));
        TaskDialog.Show(ProductInfo.Name, $"Starter bars created: {result.RebarElementsCreated}\nColumns processed: {result.HostsProcessed}\nSkipped: {result.HostsSkipped}" + notes);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ExportRebarBbsCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Rebar>().ToList();
        var rebars = selected.Count > 0
            ? selected
            : new FilteredElementCollector(ActiveDocument).OfClass(typeof(Rebar)).Cast<Rebar>().ToList();
        if (rebars.Count == 0) { TaskDialog.Show(ProductInfo.Name, "No Rebar found."); return; }
        var path = RebarDocumentationService.ExportBbs(ActiveDocument, rebars);
        TaskDialog.Show(ProductInfo.Name, $"BBS exported for {rebars.Count} Rebar element(s).\n{path}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class CreateRebarScheduleCommand : ExternalCommand
{
    public override void Execute()
    {
        var name = PromptDialog.AskText("AP-Rebar Schedule", "Schedule name:", "AP - Rebar Schedule");
        if (name is null) return;
        ViewSchedule? schedule = null;
        TransactionUtils.Run(ActiveDocument, "AP-Rebar Schedule", () => schedule = RebarDocumentationService.CreateRebarSchedule(ActiveDocument, name));
        if (schedule is not null) ActiveUiDocument.ActiveView = schedule;
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class CreateRebarReview3DCommand : ExternalCommand
{
    public override void Execute()
    {
        var hosts = SelectionUtils.GetSelectedElements(ActiveUiDocument).Where(RebarEngineService.IsSupportedHost).ToList();
        if (hosts.Count == 0)
        {
            var selectedRebar = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Rebar>().ToList();
            var hostIds = selectedRebar.Select(r => r.GetHostId()).Where(id => id != ElementId.InvalidElementId).Distinct().ToList();
            hosts = hostIds.Select(id => ActiveDocument.GetElement(id)).Where(x => x is not null).Cast<Element>().ToList();
        }
        if (hosts.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select reinforced hosts or Rebar first."); return; }
        View3D? view = null;
        TransactionUtils.Run(ActiveDocument, "AP-Rebar Review 3D", () => view = RebarDocumentationService.CreateReview3D(ActiveDocument, hosts));
        if (view is not null) ActiveUiDocument.ActiveView = view;
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class CreateRebarDetailSectionsCommand : ExternalCommand
{
    public override void Execute()
    {
        var hosts = SelectionUtils.GetSelectedElements(ActiveUiDocument).Where(RebarEngineService.IsSupportedHost).ToList();
        if (hosts.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select reinforced hosts first."); return; }
        IReadOnlyList<ViewSection> views = Array.Empty<ViewSection>();
        TransactionUtils.Run(ActiveDocument, "AP-Rebar Detail Sections", () => views = RebarDocumentationService.CreateDetailSections(ActiveDocument, hosts));
        if (views.Count > 0) ActiveUiDocument.ActiveView = views[0];
        TaskDialog.Show(ProductInfo.Name, $"Created {views.Count} rebar detail section view(s). Unsupported host orientations were skipped.");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectApRebarCommand : ExternalCommand
{
    public override void Execute()
    {
        var ids = new FilteredElementCollector(ActiveDocument)
            .OfClass(typeof(Rebar))
            .Cast<Rebar>()
            .Where(r => (r.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)?.AsString() ?? "").StartsWith("AP-Rebar", StringComparison.OrdinalIgnoreCase))
            .Select(r => r.Id)
            .ToList();
        ActiveUiDocument.Selection.SetElementIds(ids);
        TaskDialog.Show(ProductInfo.Name, $"Selected {ids.Count} AP-Rebar element(s).");
    }
}
