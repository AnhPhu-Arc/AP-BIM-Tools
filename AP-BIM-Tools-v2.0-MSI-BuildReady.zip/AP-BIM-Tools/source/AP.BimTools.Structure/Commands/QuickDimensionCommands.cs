using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Nice3point.Revit.Toolkit.External;
using AP.BimTools.Core;
using AP.BimTools.Core.Services;
using AP.BimTools.Core.UI;
using AP.BimTools.Core.Utilities;

namespace AP.BimTools.Structure.Commands;

internal static class QuickDimCommandHelpers
{
    public static double? AskOffset(string title, double defaultMm) =>
        PromptDialog.AskDouble(title, "Dimension offset (mm):", defaultMm);

    public static void ShowResult(QuickDimensionResult result)
    {
        var message = $"Created {result.Created} dimension string(s).";
        if (result.Skipped > 0) message += $"\nSkipped/unsupported references: {result.Skipped}.";
        if (!string.IsNullOrWhiteSpace(result.Message)) message += $"\n\n{result.Message}";
        TaskDialog.Show(ProductInfo.Name, message);
    }

    public static List<FamilyInstance> SelectedOrVisibleFamilyInstances(UIDocument uiDoc, BuiltInCategory category)
    {
        var selected = SelectionUtils.GetSelectedElements(uiDoc).OfType<FamilyInstance>()
            .Where(x => CategoryUtils.Is(x, category)).ToList();
        if (selected.Count > 0) return selected;
        return new FilteredElementCollector(uiDoc.Document, uiDoc.ActiveView.Id)
            .OfCategory(category).WhereElementIsNotElementType().OfType<FamilyInstance>().ToList();
    }

    public static bool IsPileLike(Document doc, FamilyInstance instance)
    {
        var type = doc.GetElement(instance.GetTypeId());
        var name = $"{instance.Symbol?.Family?.Name} {type?.Name}".ToLowerInvariant();
        return name.Contains("pile") || name.Contains("cọc") || name.Contains("coc") || name.Contains("spun") || name.Contains("phc");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class QuickDimGridCommand : ExternalCommand
{
    public override void Execute()
    {
        var offset = QuickDimCommandHelpers.AskOffset("AP - Quick Dim Grid", 1500); if (offset is null) return;
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Grid>().ToList();
        QuickDimensionResult result = new(0, 0);
        TransactionUtils.Run(ActiveDocument, "AP - Quick Dim Grid", () => result = QuickDimensionService.DimensionVisibleGrids(ActiveDocument, ActiveDocument.ActiveView, offset.Value, selected.Count >= 2 ? selected : null));
        QuickDimCommandHelpers.ShowResult(result);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class QuickDimLevelCommand : ExternalCommand
{
    public override void Execute()
    {
        var offset = QuickDimCommandHelpers.AskOffset("AP - Quick Dim Level", 1200); if (offset is null) return;
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Level>().ToList();
        QuickDimensionResult result = new(0, 0);
        TransactionUtils.Run(ActiveDocument, "AP - Quick Dim Level", () => result = QuickDimensionService.DimensionVisibleLevels(ActiveDocument, ActiveDocument.ActiveView, offset.Value, selected.Count >= 2 ? selected : null));
        QuickDimCommandHelpers.ShowResult(result);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class QuickDimWallPlanCommand : ExternalCommand
{
    public override void Execute()
    {
        var walls = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<Wall>().ToList();
        if (walls.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select the wall(s) to dimension first. AP will dimension the wall faces in each parallel group."); return; }
        var offset = QuickDimCommandHelpers.AskOffset("AP - Quick Dim Wall Plan", 800); if (offset is null) return;
        QuickDimensionResult result = new(0, 0);
        TransactionUtils.Run(ActiveDocument, "AP - Quick Dim Wall Plan", () => result = QuickDimensionService.DimensionWallFaces(ActiveDocument, ActiveDocument.ActiveView, walls, offset.Value));
        QuickDimCommandHelpers.ShowResult(result);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class QuickDimPilePlanCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument).OfType<FamilyInstance>()
            .Where(fi => CategoryUtils.Is(fi, BuiltInCategory.OST_StructuralFoundation) && fi.Location is LocationPoint).ToList();
        var piles = selected.Count >= 2
            ? selected
            : new FilteredElementCollector(ActiveDocument, ActiveDocument.ActiveView.Id)
                .OfCategory(BuiltInCategory.OST_StructuralFoundation).WhereElementIsNotElementType().OfType<FamilyInstance>()
                .Where(fi => fi.Location is LocationPoint && QuickDimCommandHelpers.IsPileLike(ActiveDocument, fi)).ToList();
        if (piles.Count < 2) { TaskDialog.Show(ProductInfo.Name, "Select at least two pile family instances. Without a selection AP only auto-detects Pile/Cọc/PHC/Spun family/type names."); return; }
        var offset = QuickDimCommandHelpers.AskOffset("AP - Quick Dim Pile Plan", 1000); if (offset is null) return;
        QuickDimensionResult result = new(0, 0);
        TransactionUtils.Run(ActiveDocument, "AP - Quick Dim Pile Plan", () => result = QuickDimensionService.DimensionFamilyCenters(ActiveDocument, ActiveDocument.ActiveView, piles, offset.Value));
        QuickDimCommandHelpers.ShowResult(result);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class QuickDimColumnPlanCommand : ExternalCommand
{
    public override void Execute()
    {
        var columns = QuickDimCommandHelpers.SelectedOrVisibleFamilyInstances(ActiveUiDocument, BuiltInCategory.OST_StructuralColumns)
            .Where(fi => fi.Location is LocationPoint).ToList();
        if (columns.Count < 2) { TaskDialog.Show(ProductInfo.Name, "Select at least two structural columns, or run the command in a plan view containing structural columns."); return; }
        var offset = QuickDimCommandHelpers.AskOffset("AP - Quick Dim Column Plan", 1000); if (offset is null) return;
        QuickDimensionResult result = new(0, 0);
        TransactionUtils.Run(ActiveDocument, "AP - Quick Dim Column Plan", () => result = QuickDimensionService.DimensionFamilyCenters(ActiveDocument, ActiveDocument.ActiveView, columns, offset.Value));
        QuickDimCommandHelpers.ShowResult(result);
    }
}
