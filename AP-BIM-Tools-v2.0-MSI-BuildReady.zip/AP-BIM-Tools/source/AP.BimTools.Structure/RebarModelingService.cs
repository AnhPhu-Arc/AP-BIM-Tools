using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;

namespace AP.BimTools.Structure;

internal static class RebarModelingService
{
    internal sealed record CreateResult(int Created, int Skipped, string? Note = null);

    public static RebarBarType? FindClosestBarType(Document doc, double diameterMm)
    {
        var target = UnitUtils.ConvertToInternalUnits(diameterMm, UnitTypeId.Millimeters);
        return new FilteredElementCollector(doc).OfClass(typeof(RebarBarType)).Cast<RebarBarType>()
            .OrderBy(t => Math.Abs(t.BarNominalDiameter - target)).FirstOrDefault();
    }

    public static CreateResult CreateBeamLongitudinal(Document doc, IEnumerable<FamilyInstance> beams, RebarBarType barType, double coverMm)
    {
        var created = 0;
        var skipped = 0;
        var cover = Mm(coverMm);
        var radius = barType.BarModelDiameter * 0.5;

        foreach (var beam in beams)
        {
            try
            {
                if (beam.Location is not LocationCurve { Curve: Line axis }) { skipped++; continue; }
                var x = axis.Direction.Normalize();
                var z = XYZ.BasisZ;
                if (Math.Abs(x.DotProduct(z)) > 0.02) { skipped++; continue; }
                var y = z.CrossProduct(x).Normalize();
                if (!TryGetProjectedExtents(beam, x, y, z, out var e)) { skipped++; continue; }

                var edge = cover + radius;
                if (e.MaxY - e.MinY <= 2 * edge || e.MaxZ - e.MinZ <= 2 * edge || e.MaxX - e.MinX <= 2 * edge) { skipped++; continue; }

                var ys = new[] { e.MinY + edge, e.MaxY - edge };
                var zs = new[] { e.MinZ + edge, e.MaxZ - edge };
                var x0 = e.MinX + edge;
                var x1 = e.MaxX - edge;
                foreach (var yy in ys)
                foreach (var zz in zs)
                {
                    var p0 = Compose(x, x0, y, yy, z, zz);
                    var p1 = Compose(x, x1, y, yy, z, zz);
                    if (CreateRebar(doc, RebarStyle.Standard, barType, beam, y, [Line.CreateBound(p0, p1)]) is not null) created++;
                }
            }
            catch { skipped++; }
        }
        return new CreateResult(created, skipped, "Creates four straight corner longitudinal bars per supported beam.");
    }

    public static CreateResult CreateBeamStirrups(Document doc, IEnumerable<FamilyInstance> beams, RebarBarType barType, double coverMm, double spacingMm)
    {
        var created = 0;
        var skipped = 0;
        var cover = Mm(coverMm);
        var spacing = Mm(spacingMm);
        var radius = barType.BarModelDiameter * 0.5;

        foreach (var beam in beams)
        {
            try
            {
                if (beam.Location is not LocationCurve { Curve: Line axis }) { skipped++; continue; }
                var x = axis.Direction.Normalize();
                var z = XYZ.BasisZ;
                if (Math.Abs(x.DotProduct(z)) > 0.02) { skipped++; continue; }
                var y = z.CrossProduct(x).Normalize();
                if (!TryGetProjectedExtents(beam, x, y, z, out var e)) { skipped++; continue; }

                var edge = cover + radius;
                var y0 = e.MinY + edge; var y1 = e.MaxY - edge;
                var z0 = e.MinZ + edge; var z1 = e.MaxZ - edge;
                var x0 = e.MinX + edge;
                var length = e.MaxX - e.MinX - 2 * edge;
                if (y1 <= y0 || z1 <= z0 || length <= spacing * 0.25) { skipped++; continue; }

                var a = Compose(x, x0, y, y0, z, z0);
                var b = Compose(x, x0, y, y1, z, z0);
                var c = Compose(x, x0, y, y1, z, z1);
                var d = Compose(x, x0, y, y0, z, z1);
                var curves = new List<Curve> { Line.CreateBound(a, b), Line.CreateBound(b, c), Line.CreateBound(c, d), Line.CreateBound(d, a) };
                var rebar = CreateRebar(doc, RebarStyle.StirrupTie, barType, beam, x, curves);
                if (rebar is null) { skipped++; continue; }
                using var accessor = rebar.GetShapeDrivenAccessor();
                accessor.SetLayoutAsMaximumSpacing(spacing, length, true, true, true);
                created++;
            }
            catch { skipped++; }
        }
        return new CreateResult(created, skipped, "Creates one stirrup rebar set per supported beam using Maximum Spacing layout.");
    }

    public static CreateResult CreateColumnLongitudinal(Document doc, IEnumerable<FamilyInstance> columns, RebarBarType barType, double coverMm)
    {
        var created = 0;
        var skipped = 0;
        var cover = Mm(coverMm);
        var radius = barType.BarModelDiameter * 0.5;

        foreach (var column in columns)
        {
            try
            {
                var t = column.GetTransform();
                var x = t.BasisX.Normalize();
                var y = t.BasisY.Normalize();
                var z = t.BasisZ.Normalize();
                if (Math.Abs(z.DotProduct(XYZ.BasisZ)) < 0.98) { skipped++; continue; }
                if (!TryGetProjectedExtents(column, x, y, z, out var e)) { skipped++; continue; }

                var edge = cover + radius;
                if (e.MaxX - e.MinX <= 2 * edge || e.MaxY - e.MinY <= 2 * edge || e.MaxZ - e.MinZ <= 2 * edge) { skipped++; continue; }
                var xs = new[] { e.MinX + edge, e.MaxX - edge };
                var ys = new[] { e.MinY + edge, e.MaxY - edge };
                var z0 = e.MinZ + edge; var z1 = e.MaxZ - edge;
                foreach (var xx in xs)
                foreach (var yy in ys)
                {
                    var p0 = Compose(x, xx, y, yy, z, z0);
                    var p1 = Compose(x, xx, y, yy, z, z1);
                    if (CreateRebar(doc, RebarStyle.Standard, barType, column, x, [Line.CreateBound(p0, p1)]) is not null) created++;
                }
            }
            catch { skipped++; }
        }
        return new CreateResult(created, skipped, "Creates four straight corner longitudinal bars per supported vertical column.");
    }

    public static CreateResult CreateColumnTies(Document doc, IEnumerable<FamilyInstance> columns, RebarBarType barType, double coverMm, double spacingMm)
    {
        var created = 0;
        var skipped = 0;
        var cover = Mm(coverMm);
        var spacing = Mm(spacingMm);
        var radius = barType.BarModelDiameter * 0.5;

        foreach (var column in columns)
        {
            try
            {
                var t = column.GetTransform();
                var x = t.BasisX.Normalize();
                var y = t.BasisY.Normalize();
                var z = t.BasisZ.Normalize();
                if (Math.Abs(z.DotProduct(XYZ.BasisZ)) < 0.98) { skipped++; continue; }
                if (!TryGetProjectedExtents(column, x, y, z, out var e)) { skipped++; continue; }

                var edge = cover + radius;
                var x0 = e.MinX + edge; var x1 = e.MaxX - edge;
                var y0 = e.MinY + edge; var y1 = e.MaxY - edge;
                var z0 = e.MinZ + edge;
                var length = e.MaxZ - e.MinZ - 2 * edge;
                if (x1 <= x0 || y1 <= y0 || length <= spacing * 0.25) { skipped++; continue; }

                var a = Compose(x, x0, y, y0, z, z0);
                var b = Compose(x, x1, y, y0, z, z0);
                var c = Compose(x, x1, y, y1, z, z0);
                var d = Compose(x, x0, y, y1, z, z0);
                var curves = new List<Curve> { Line.CreateBound(a, b), Line.CreateBound(b, c), Line.CreateBound(c, d), Line.CreateBound(d, a) };
                var rebar = CreateRebar(doc, RebarStyle.StirrupTie, barType, column, z, curves);
                if (rebar is null) { skipped++; continue; }
                using var accessor = rebar.GetShapeDrivenAccessor();
                accessor.SetLayoutAsMaximumSpacing(spacing, length, true, true, true);
                created++;
            }
            catch { skipped++; }
        }
        return new CreateResult(created, skipped, "Creates one closed tie rebar set per supported vertical column using Maximum Spacing layout.");
    }

    private static Rebar? CreateRebar(Document doc, RebarStyle style, RebarBarType barType, Element host, XYZ normal, IList<Curve> curves)
    {
#if REVIT2026_OR_GREATER
        using var terminations = new BarTerminationsData(doc);
        return Rebar.CreateFromCurves(doc, style, barType, host, normal, curves, terminations, true, true);
#else
        return Rebar.CreateFromCurves(doc, style, barType, null, null, host, normal, curves,
            RebarHookOrientation.Right, RebarHookOrientation.Right, true, true);
#endif
    }

    private sealed record Extents(double MinX, double MaxX, double MinY, double MaxY, double MinZ, double MaxZ);

    private static bool TryGetProjectedExtents(Element element, XYZ x, XYZ y, XYZ z, out Extents extents)
    {
        var points = GetGeometryPoints(element).ToList();
        if (points.Count < 4)
        {
            var box = element.get_BoundingBox(null);
            if (box is not null) points.AddRange(BoundingBoxCorners(box));
        }
        if (points.Count < 2) { extents = new Extents(0, 0, 0, 0, 0, 0); return false; }

        var px = points.Select(p => p.DotProduct(x)).ToList();
        var py = points.Select(p => p.DotProduct(y)).ToList();
        var pz = points.Select(p => p.DotProduct(z)).ToList();
        extents = new Extents(px.Min(), px.Max(), py.Min(), py.Max(), pz.Min(), pz.Max());
        return extents.MaxX > extents.MinX && extents.MaxY > extents.MinY && extents.MaxZ > extents.MinZ;
    }

    private static IEnumerable<XYZ> GetGeometryPoints(Element element)
    {
        var options = new Options { DetailLevel = ViewDetailLevel.Fine, IncludeNonVisibleObjects = false, ComputeReferences = false };
        var geometry = element.get_Geometry(options);
        if (geometry is null) yield break;
        foreach (var p in GeometryPoints(geometry)) yield return p;
    }

    private static IEnumerable<XYZ> GeometryPoints(GeometryElement geometry)
    {
        foreach (var obj in geometry)
        {
            switch (obj)
            {
                case Solid solid when solid.Volume > 1e-9:
                    foreach (Edge edge in solid.Edges)
                    {
                        var curve = edge.AsCurve();
                        yield return curve.GetEndPoint(0);
                        yield return curve.GetEndPoint(1);
                    }
                    break;
                case GeometryInstance instance:
                    foreach (var p in GeometryPoints(instance.GetInstanceGeometry())) yield return p;
                    break;
            }
        }
    }

    private static IEnumerable<XYZ> BoundingBoxCorners(BoundingBoxXYZ b)
    {
        for (var ix = 0; ix < 2; ix++)
        for (var iy = 0; iy < 2; iy++)
        for (var iz = 0; iz < 2; iz++)
        {
            var p = new XYZ(ix == 0 ? b.Min.X : b.Max.X, iy == 0 ? b.Min.Y : b.Max.Y, iz == 0 ? b.Min.Z : b.Max.Z);
            yield return b.Transform.OfPoint(p);
        }
    }

    private static XYZ Compose(XYZ x, double xv, XYZ y, double yv, XYZ z, double zv) =>
        x.Multiply(xv) + y.Multiply(yv) + z.Multiply(zv);

    private static double Mm(double mm) => UnitUtils.ConvertToInternalUnits(mm, UnitTypeId.Millimeters);
}
