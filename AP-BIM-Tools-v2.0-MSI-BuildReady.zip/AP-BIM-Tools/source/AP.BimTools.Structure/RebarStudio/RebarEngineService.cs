using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;

namespace AP.BimTools.Structure.RebarStudio;

internal sealed record RebarEngineResult(
    int HostsProcessed,
    int HostsSkipped,
    int RebarElementsCreated,
    int RebarElementsDeleted,
    IReadOnlyList<string> Notes)
{
    public static RebarEngineResult Empty => new(0, 0, 0, 0, Array.Empty<string>());
}

internal static class RebarEngineService
{
    private const double Tolerance = 1e-6;

    public static bool IsSupportedHost(Element e) => e switch
    {
        FamilyInstance fi when IsCategory(fi, BuiltInCategory.OST_StructuralFraming) => true,
        FamilyInstance fi when IsCategory(fi, BuiltInCategory.OST_StructuralColumns) => true,
        FamilyInstance fi when IsCategory(fi, BuiltInCategory.OST_StructuralFoundation) => true,
        Wall => true,
        Floor => true,
        _ => false
    };

    public static RebarStudioMode ModeForHost(Element e) => e switch
    {
        FamilyInstance fi when IsCategory(fi, BuiltInCategory.OST_StructuralFraming) => RebarStudioMode.Beam,
        FamilyInstance fi when IsCategory(fi, BuiltInCategory.OST_StructuralColumns) => RebarStudioMode.Column,
        FamilyInstance fi when IsCategory(fi, BuiltInCategory.OST_StructuralFoundation) => RebarStudioMode.Foundation,
        Wall => RebarStudioMode.Wall,
        Floor => RebarStudioMode.Slab,
        _ => RebarStudioMode.Auto
    };

    public static RebarEngineResult Apply(Document doc, IReadOnlyList<Element> hosts, RebarStudioOptions options)
    {
        var processed = 0;
        var skipped = 0;
        var created = 0;
        var deleted = 0;
        var notes = new List<string>();

        foreach (var host in hosts.Where(IsSupportedHost))
        {
            var mode = options.Mode == RebarStudioMode.Auto ? ModeForHost(host) : options.Mode;
            if (!HostMatchesMode(host, mode) || !GeometryLooksSupported(host, mode))
            {
                skipped++;
                notes.Add($"Skipped {host.Id}: unsupported {mode} geometry/category.");
                continue;
            }

            using var sub = new SubTransaction(doc);
            try
            {
                sub.Start();
                var deletedForHost = options.ReplaceExisting ? DeleteHostedRebar(doc, host.Id) : 0;
                var count = mode switch
                {
                    RebarStudioMode.Beam => CreateBeam(doc, (FamilyInstance)host, options),
                    RebarStudioMode.Column => CreateColumn(doc, (FamilyInstance)host, options),
                    RebarStudioMode.Wall => CreateWall(doc, (Wall)host, options),
                    RebarStudioMode.Slab => CreateSlab(doc, (Floor)host, options),
                    RebarStudioMode.Foundation => CreateFoundation(doc, (FamilyInstance)host, options),
                    _ => 0
                };
                if (count <= 0)
                {
                    sub.RollBack();
                    skipped++;
                    notes.Add($"No rebar created for host {host.Id}; existing reinforcement was preserved.");
                    continue;
                }
                sub.Commit();
                deleted += deletedForHost;
                created += count;
                processed++;
            }
            catch (Exception ex)
            {
                if (sub.GetStatus() == TransactionStatus.Started) sub.RollBack();
                skipped++;
                notes.Add($"Host {host.Id}: {ex.Message}");
            }
        }

        return new RebarEngineResult(processed, skipped, created, deleted, notes.Take(12).ToList());
    }

    public static int DeleteHostedRebar(Document doc, IEnumerable<ElementId> hostIds)
    {
        var ids = new HashSet<ElementId>(hostIds);
        var rebarIds = new FilteredElementCollector(doc)
            .OfClass(typeof(Rebar))
            .Cast<Rebar>()
            .Where(r => ids.Contains(r.GetHostId()))
            .Select(r => r.Id)
            .ToList();
        if (rebarIds.Count > 0) doc.Delete(rebarIds);
        return rebarIds.Count;
    }

    private static int DeleteHostedRebar(Document doc, ElementId hostId) => DeleteHostedRebar(doc, new[] { hostId });

    private static bool HostMatchesMode(Element host, RebarStudioMode mode) => mode switch
    {
        RebarStudioMode.Beam => host is FamilyInstance fi && IsCategory(fi, BuiltInCategory.OST_StructuralFraming),
        RebarStudioMode.Column => host is FamilyInstance fi && IsCategory(fi, BuiltInCategory.OST_StructuralColumns),
        RebarStudioMode.Wall => host is Wall,
        RebarStudioMode.Slab => host is Floor,
        RebarStudioMode.Foundation => host is FamilyInstance fi && IsCategory(fi, BuiltInCategory.OST_StructuralFoundation),
        RebarStudioMode.Auto => IsSupportedHost(host),
        _ => false
    };

    private static bool GeometryLooksSupported(Element host, RebarStudioMode mode)
    {
        if (host.get_BoundingBox(null) is null) return false;
        return mode switch
        {
            RebarStudioMode.Beam => host.Location is LocationCurve { Curve: Line line } && Math.Abs(line.Direction.Normalize().DotProduct(XYZ.BasisZ)) < 0.05,
            RebarStudioMode.Column => host is FamilyInstance fi && Math.Abs(fi.GetTransform().BasisZ.Normalize().DotProduct(XYZ.BasisZ)) > 0.98,
            RebarStudioMode.Wall => host.Location is LocationCurve { Curve: Line line } && Math.Abs(line.Direction.Normalize().DotProduct(XYZ.BasisZ)) < 0.05,
            RebarStudioMode.Slab => IsNearlyHorizontalBox(host.get_BoundingBox(null)!),
            RebarStudioMode.Foundation => host is FamilyInstance foundation && Math.Abs(foundation.GetTransform().BasisZ.Normalize().DotProduct(XYZ.BasisZ)) > 0.98,
            _ => false
        };
    }

    private static bool IsNearlyHorizontalBox(BoundingBoxXYZ box) => box.Max.Z - box.Min.Z > Tolerance;

    private static int CreateBeam(Document doc, FamilyInstance beam, RebarStudioOptions o)
    {
        if (beam.Location is not LocationCurve { Curve: Line axis }) return 0;
        var x = axis.Direction.Normalize();
        var z = XYZ.BasisZ;
        var y = z.CrossProduct(x).Normalize();
        if (!TryGetProjectedExtents(beam, x, y, z, out var e)) return 0;

        var topType = RequireBarType(doc, o.BeamTopDiameterMm);
        var bottomType = RequireBarType(doc, o.BeamBottomDiameterMm);
        var stirrupType = RequireBarType(doc, o.BeamStirrupDiameterMm);
        var extraType = o.BeamExtraTopCount > 0 ? RequireBarType(doc, o.BeamExtraTopDiameterMm) : topType;

        var cover = Mm(o.CoverMm);
        var created = 0;
        created += CreateBeamLayer(doc, beam, x, y, z, e, topType, o.BeamTopCount, true, cover);
        created += CreateBeamLayer(doc, beam, x, y, z, e, bottomType, o.BeamBottomCount, false, cover);

        if (o.BeamExtraTopCount > 0 && o.BeamExtraSupportRatio > 0)
            created += CreateBeamSupportExtraBars(doc, beam, x, y, z, e, extraType, o.BeamExtraTopCount, cover, o.BeamExtraSupportRatio);

        created += CreateBeamStirrupZones(doc, beam, x, y, z, e, stirrupType, cover,
            o.BeamSupportZoneRatio, o.BeamSupportSpacingMm, o.BeamMidSpacingMm);
        return created;
    }

    private static int CreateBeamLayer(Document doc, FamilyInstance host, XYZ x, XYZ y, XYZ z, AxisExtents e,
        RebarBarType barType, int count, bool top, double cover)
    {
        if (count <= 0) return 0;
        var radius = barType.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var x0 = e.MinX + edge;
        var x1 = e.MaxX - edge;
        var y0 = e.MinY + edge;
        var y1 = e.MaxY - edge;
        var zz = top ? e.MaxZ - edge : e.MinZ + edge;
        if (x1 <= x0 || y1 < y0) return 0;

        var created = 0;
        foreach (var yy in Linspace(y0, y1, count))
        {
            var p0 = Compose(x, x0, y, yy, z, zz);
            var p1 = Compose(x, x1, y, yy, z, zz);
            var rebar = CreateRebar(doc, RebarStyle.Standard, barType, host, y, new List<Curve> { Line.CreateBound(p0, p1) });
            if (rebar is null) continue;
            Stamp(rebar, top ? "AP-Rebar Beam Top" : "AP-Rebar Beam Bottom");
            created++;
        }
        return created;
    }

    private static int CreateBeamSupportExtraBars(Document doc, FamilyInstance host, XYZ x, XYZ y, XYZ z, AxisExtents e,
        RebarBarType barType, int count, double cover, double supportRatio)
    {
        var radius = barType.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var x0 = e.MinX + edge;
        var x1 = e.MaxX - edge;
        var total = x1 - x0;
        if (total <= Tolerance) return 0;
        var extraLength = Math.Min(total * supportRatio, total * 0.49);
        if (extraLength <= Tolerance) return 0;

        var y0 = e.MinY + edge;
        var y1 = e.MaxY - edge;
        var zz = e.MaxZ - edge - Math.Max(Mm(12), barType.BarModelDiameter * 1.75);
        if (zz <= e.MinZ + edge) return 0;

        var created = 0;
        foreach (var yy in Linspace(y0, y1, count))
        {
            foreach (var segment in new[] { (x0, x0 + extraLength), (x1 - extraLength, x1) })
            {
                var p0 = Compose(x, segment.Item1, y, yy, z, zz);
                var p1 = Compose(x, segment.Item2, y, yy, z, zz);
                var rebar = CreateRebar(doc, RebarStyle.Standard, barType, host, y, new List<Curve> { Line.CreateBound(p0, p1) });
                if (rebar is null) continue;
                Stamp(rebar, "AP-Rebar Beam Support Extra");
                created++;
            }
        }
        return created;
    }

    private static int CreateBeamStirrupZones(Document doc, FamilyInstance host, XYZ x, XYZ y, XYZ z, AxisExtents e,
        RebarBarType barType, double cover, double supportRatio, double supportSpacingMm, double midSpacingMm)
    {
        var radius = barType.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var x0 = e.MinX + edge;
        var x1 = e.MaxX - edge;
        var length = x1 - x0;
        if (length <= Tolerance) return 0;
        var zone = Math.Min(length * supportRatio, length * 0.45);
        var created = 0;

        if (zone > Mm(30))
        {
            created += CreateRectangularSet(doc, host, barType, x, y, z, e, x0, zone, cover, supportSpacingMm, true, "AP-Rebar Beam Stirrup Left");
            created += CreateRectangularSet(doc, host, barType, x, y, z, e, x1 - zone, zone, cover, supportSpacingMm, true, "AP-Rebar Beam Stirrup Right");
        }
        var midStart = x0 + zone;
        var midLength = length - 2 * zone;
        if (midLength > Mm(30))
            created += CreateRectangularSet(doc, host, barType, x, y, z, e, midStart, midLength, cover, midSpacingMm, true, "AP-Rebar Beam Stirrup Mid");
        return created;
    }

    private static int CreateRectangularSet(Document doc, Element host, RebarBarType barType, XYZ axis, XYZ y, XYZ z,
        AxisExtents e, double axisPosition, double arrayLength, double cover, double spacingMm, bool beamShape, string stamp)
    {
        var radius = barType.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var y0 = e.MinY + edge;
        var y1 = e.MaxY - edge;
        var z0 = e.MinZ + edge;
        var z1 = e.MaxZ - edge;
        if (y1 <= y0 || z1 <= z0 || arrayLength <= Tolerance) return 0;

        var a = Compose(axis, axisPosition, y, y0, z, z0);
        var b = Compose(axis, axisPosition, y, y1, z, z0);
        var c = Compose(axis, axisPosition, y, y1, z, z1);
        var d = Compose(axis, axisPosition, y, y0, z, z1);
        var curves = new List<Curve> { Line.CreateBound(a, b), Line.CreateBound(b, c), Line.CreateBound(c, d), Line.CreateBound(d, a) };
        var rebar = CreateRebar(doc, RebarStyle.StirrupTie, barType, host, axis, curves);
        if (rebar is null) return 0;
        using var accessor = rebar.GetShapeDrivenAccessor();
        accessor.SetLayoutAsMaximumSpacing(Mm(spacingMm), arrayLength, true, true, true);
        Stamp(rebar, stamp);
        return 1;
    }

    private static int CreateColumn(Document doc, FamilyInstance column, RebarStudioOptions o)
    {
        var t = column.GetTransform();
        var x = t.BasisX.Normalize();
        var y = t.BasisY.Normalize();
        var z = t.BasisZ.Normalize();
        if (!TryGetProjectedExtents(column, x, y, z, out var e)) return 0;

        var mainType = RequireBarType(doc, o.ColumnMainDiameterMm);
        var tieType = RequireBarType(doc, o.ColumnTieDiameterMm);
        var cover = Mm(o.CoverMm);
        var radius = mainType.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var x0 = e.MinX + edge; var x1 = e.MaxX - edge;
        var y0 = e.MinY + edge; var y1 = e.MaxY - edge;
        var z0 = e.MinZ + edge; var z1 = e.MaxZ - edge;
        if (x1 <= x0 || y1 <= y0 || z1 <= z0) return 0;

        var points = new List<(double X, double Y)>();
        foreach (var xx in Linspace(x0, x1, o.ColumnBarsX))
        {
            points.Add((xx, y0));
            points.Add((xx, y1));
        }
        foreach (var yy in Linspace(y0, y1, o.ColumnBarsY).Skip(1).Take(Math.Max(0, o.ColumnBarsY - 2)))
        {
            points.Add((x0, yy));
            points.Add((x1, yy));
        }

        var created = 0;
        foreach (var p in points)
        {
            var a = Compose(x, p.X, y, p.Y, z, z0);
            var b = Compose(x, p.X, y, p.Y, z, z1);
            var rebar = CreateRebar(doc, RebarStyle.Standard, mainType, column, x, new List<Curve> { Line.CreateBound(a, b) });
            if (rebar is null) continue;
            Stamp(rebar, "AP-Rebar Column Main");
            created++;
        }

        created += CreateColumnTieZones(doc, column, x, y, z, e, tieType, cover, o.ColumnEndZoneRatio, o.ColumnEndSpacingMm, o.ColumnMidSpacingMm);
        return created;
    }

    private static int CreateColumnTieZones(Document doc, FamilyInstance host, XYZ x, XYZ y, XYZ z, AxisExtents e,
        RebarBarType type, double cover, double endRatio, double endSpacingMm, double midSpacingMm)
    {
        var radius = type.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var z0 = e.MinZ + edge;
        var z1 = e.MaxZ - edge;
        var height = z1 - z0;
        if (height <= Tolerance) return 0;
        var end = Math.Min(height * endRatio, height * 0.45);
        var created = 0;
        if (end > Mm(30))
        {
            created += CreateColumnTieSet(doc, host, type, x, y, z, e, z0, end, cover, endSpacingMm, "AP-Rebar Column Tie Bottom");
            created += CreateColumnTieSet(doc, host, type, x, y, z, e, z1 - end, end, cover, endSpacingMm, "AP-Rebar Column Tie Top");
        }
        var midHeight = height - 2 * end;
        if (midHeight > Mm(30))
            created += CreateColumnTieSet(doc, host, type, x, y, z, e, z0 + end, midHeight, cover, midSpacingMm, "AP-Rebar Column Tie Mid");
        return created;
    }

    private static int CreateColumnTieSet(Document doc, Element host, RebarBarType type, XYZ x, XYZ y, XYZ z,
        AxisExtents e, double zPosition, double arrayLength, double cover, double spacingMm, string stamp)
    {
        var radius = type.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var x0 = e.MinX + edge; var x1 = e.MaxX - edge;
        var y0 = e.MinY + edge; var y1 = e.MaxY - edge;
        if (x1 <= x0 || y1 <= y0) return 0;
        var a = Compose(x, x0, y, y0, z, zPosition);
        var b = Compose(x, x1, y, y0, z, zPosition);
        var c = Compose(x, x1, y, y1, z, zPosition);
        var d = Compose(x, x0, y, y1, z, zPosition);
        var rebar = CreateRebar(doc, RebarStyle.StirrupTie, type, host, z,
            new List<Curve> { Line.CreateBound(a, b), Line.CreateBound(b, c), Line.CreateBound(c, d), Line.CreateBound(d, a) });
        if (rebar is null) return 0;
        using var accessor = rebar.GetShapeDrivenAccessor();
        accessor.SetLayoutAsMaximumSpacing(Mm(spacingMm), arrayLength, true, true, true);
        Stamp(rebar, stamp);
        return 1;
    }

    private static int CreateWall(Document doc, Wall wall, RebarStudioOptions o)
    {
        if (wall.Location is not LocationCurve { Curve: Line axis }) return 0;
        var p0 = axis.GetEndPoint(0);
        var p1 = axis.GetEndPoint(1);
        var x = (p1 - p0).Normalize();
        var z = XYZ.BasisZ;
        var n = x.CrossProduct(z).Normalize();
        var box = wall.get_BoundingBox(null);
        if (box is null) return 0;

        var verticalType = RequireBarType(doc, o.WallVerticalDiameterMm);
        var horizontalType = RequireBarType(doc, o.WallHorizontalDiameterMm);
        var boundaryType = o.WallBoundaryBars > 0 ? RequireBarType(doc, o.WallBoundaryDiameterMm) : verticalType;
        var cover = Mm(o.CoverMm);
        var length = axis.Length;
        var zMin = box.Min.Z;
        var zMax = box.Max.Z;
        var created = 0;
        var faceSigns = o.WallBothFaces ? new[] { -1.0, 1.0 } : new[] { 1.0 };

        foreach (var sign in faceSigns)
        {
            created += CreateWallVerticalSet(doc, wall, p0, x, n, zMin, zMax, length, sign, verticalType, cover, o.WallVerticalSpacingMm);
            created += CreateWallHorizontalSet(doc, wall, p0, x, n, zMin, zMax, length, sign, horizontalType, cover, o.WallHorizontalSpacingMm);
            created += CreateWallBoundaryBars(doc, wall, p0, x, n, zMin, zMax, length, sign, boundaryType, cover, o.WallBoundaryBars);
        }
        return created;
    }

    private static int CreateWallVerticalSet(Document doc, Wall wall, XYZ origin, XYZ x, XYZ n, double zMin, double zMax,
        double length, double faceSign, RebarBarType type, double cover, double spacingMm)
    {
        var radius = type.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var clearLength = length - 2 * edge;
        var z0 = zMin + edge;
        var z1 = zMax - edge;
        var faceOffset = Math.Max(0, wall.Width * 0.5 - edge) * faceSign;
        if (clearLength <= Tolerance || z1 <= z0) return 0;
        var basePoint = origin + x.Multiply(edge) + n.Multiply(faceOffset);
        var a = new XYZ(basePoint.X, basePoint.Y, z0);
        var b = new XYZ(basePoint.X, basePoint.Y, z1);
        var rebar = CreateRebar(doc, RebarStyle.Standard, type, wall, n, new List<Curve> { Line.CreateBound(a, b) });
        if (rebar is null) return 0;
        using var accessor = rebar.GetShapeDrivenAccessor();
        accessor.SetLayoutAsMaximumSpacing(Mm(spacingMm), clearLength, true, true, true);
        Stamp(rebar, "AP-Rebar Wall Vertical");
        return 1;
    }

    private static int CreateWallHorizontalSet(Document doc, Wall wall, XYZ origin, XYZ x, XYZ n, double zMin, double zMax,
        double length, double faceSign, RebarBarType type, double cover, double spacingMm)
    {
        var radius = type.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var clearLength = length - 2 * edge;
        var clearHeight = zMax - zMin - 2 * edge;
        var faceOffset = Math.Max(0, wall.Width * 0.5 - edge) * faceSign;
        if (clearLength <= Tolerance || clearHeight <= Tolerance) return 0;
        var a0 = origin + x.Multiply(edge) + n.Multiply(faceOffset);
        var b0 = origin + x.Multiply(length - edge) + n.Multiply(faceOffset);
        var a = new XYZ(a0.X, a0.Y, zMin + edge);
        var b = new XYZ(b0.X, b0.Y, zMin + edge);
        var rebar = CreateRebar(doc, RebarStyle.Standard, type, wall, n, new List<Curve> { Line.CreateBound(a, b) });
        if (rebar is null) return 0;
        using var accessor = rebar.GetShapeDrivenAccessor();
        accessor.SetLayoutAsMaximumSpacing(Mm(spacingMm), clearHeight, true, true, true);
        Stamp(rebar, "AP-Rebar Wall Horizontal");
        return 1;
    }

    private static int CreateWallBoundaryBars(Document doc, Wall wall, XYZ origin, XYZ x, XYZ n, double zMin, double zMax,
        double length, double faceSign, RebarBarType type, double cover, int count)
    {
        if (count <= 0) return 0;
        var radius = type.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var faceOffset = Math.Max(0, wall.Width * 0.5 - edge) * faceSign;
        var z0 = zMin + edge;
        var z1 = zMax - edge;
        if (z1 <= z0) return 0;
        var created = 0;
        var step = Math.Max(type.BarModelDiameter * 2.0, Mm(30));
        for (var i = 0; i < count; i++)
        {
            var offset = edge + i * step;
            if (offset >= length * 0.5) break;
            foreach (var along in new[] { offset, length - offset })
            {
                var basePoint = origin + x.Multiply(along) + n.Multiply(faceOffset);
                var a = new XYZ(basePoint.X, basePoint.Y, z0);
                var b = new XYZ(basePoint.X, basePoint.Y, z1);
                var rebar = CreateRebar(doc, RebarStyle.Standard, type, wall, n, new List<Curve> { Line.CreateBound(a, b) });
                if (rebar is null) continue;
                Stamp(rebar, "AP-Rebar Wall Boundary");
                created++;
            }
        }
        return created;
    }

    private static int CreateSlab(Document doc, Floor floor, RebarStudioOptions o)
    {
        var box = floor.get_BoundingBox(null);
        if (box is null) return 0;
        var x = XYZ.BasisX;
        var y = XYZ.BasisY;
        var z = XYZ.BasisZ;
        var created = 0;
        var cover = Mm(o.CoverMm);

        created += CreatePlanarMat(doc, floor, x, y, z, box.Min.X, box.Max.X, box.Min.Y, box.Max.Y, box.Min.Z, true,
            RequireBarType(doc, o.SlabBottomXDiameterMm), o.SlabBottomXSpacingMm, cover, "AP-Rebar Slab Bottom X");
        created += CreatePlanarMat(doc, floor, y, x, z, box.Min.Y, box.Max.Y, box.Min.X, box.Max.X, box.Min.Z, true,
            RequireBarType(doc, o.SlabBottomYDiameterMm), o.SlabBottomYSpacingMm, cover, "AP-Rebar Slab Bottom Y");
        if (o.SlabCreateTop)
        {
            created += CreatePlanarMat(doc, floor, x, y, z, box.Min.X, box.Max.X, box.Min.Y, box.Max.Y, box.Max.Z, false,
                RequireBarType(doc, o.SlabTopXDiameterMm), o.SlabTopXSpacingMm, cover, "AP-Rebar Slab Top X");
            created += CreatePlanarMat(doc, floor, y, x, z, box.Min.Y, box.Max.Y, box.Min.X, box.Max.X, box.Max.Z, false,
                RequireBarType(doc, o.SlabTopYDiameterMm), o.SlabTopYSpacingMm, cover, "AP-Rebar Slab Top Y");
        }
        return created;
    }

    private static int CreatePlanarMat(Document doc, Element host, XYZ barAxis, XYZ distributionAxis, XYZ normal,
        double barMin, double barMax, double distributionMin, double distributionMax, double surfaceZ, bool bottom,
        RebarBarType type, double spacingMm, double cover, string stamp)
    {
        var radius = type.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var b0 = barMin + edge;
        var b1 = barMax - edge;
        var d0 = distributionMin + edge;
        var d1 = distributionMax - edge;
        var arrayLength = d1 - d0;
        if (b1 <= b0 || arrayLength <= Tolerance) return 0;
        var zz = bottom ? surfaceZ + edge : surfaceZ - edge;

        XYZ Point(double b, double d) => barAxis.Multiply(b) + distributionAxis.Multiply(d) + XYZ.BasisZ.Multiply(zz);
        var a = Point(b0, d0);
        var b = Point(b1, d0);
        var rebar = CreateRebar(doc, RebarStyle.Standard, type, host, normal, new List<Curve> { Line.CreateBound(a, b) });
        if (rebar is null) return 0;
        using var accessor = rebar.GetShapeDrivenAccessor();
        accessor.SetLayoutAsMaximumSpacing(Mm(spacingMm), arrayLength, true, true, true);
        Stamp(rebar, stamp);
        return 1;
    }

    private static int CreateFoundation(Document doc, FamilyInstance foundation, RebarStudioOptions o)
    {
        var t = foundation.GetTransform();
        var x = t.BasisX.Normalize();
        var y = t.BasisY.Normalize();
        var z = t.BasisZ.Normalize();
        if (!TryGetProjectedExtents(foundation, x, y, z, out var e)) return 0;
        var cover = Mm(o.CoverMm);
        var created = 0;

        created += CreateLocalPlanarMat(doc, foundation, x, y, z, e, e.MinZ, true,
            RequireBarType(doc, o.FoundationBottomXDiameterMm), o.FoundationBottomXSpacingMm, cover, true, "AP-Rebar Foundation Bottom X");
        created += CreateLocalPlanarMat(doc, foundation, y, x, z, SwapXy(e), e.MinZ, true,
            RequireBarType(doc, o.FoundationBottomYDiameterMm), o.FoundationBottomYSpacingMm, cover, true, "AP-Rebar Foundation Bottom Y");
        if (o.FoundationCreateTop)
        {
            created += CreateLocalPlanarMat(doc, foundation, x, y, z, e, e.MaxZ, false,
                RequireBarType(doc, o.FoundationTopXDiameterMm), o.FoundationTopXSpacingMm, cover, true, "AP-Rebar Foundation Top X");
            created += CreateLocalPlanarMat(doc, foundation, y, x, z, SwapXy(e), e.MaxZ, false,
                RequireBarType(doc, o.FoundationTopYDiameterMm), o.FoundationTopYSpacingMm, cover, true, "AP-Rebar Foundation Top Y");
        }
        return created;
    }

    private static int CreateLocalPlanarMat(Document doc, Element host, XYZ barAxis, XYZ distributionAxis, XYZ zAxis,
        AxisExtents e, double surfaceZ, bool bottom, RebarBarType type, double spacingMm, double cover, bool useExtents, string stamp)
    {
        var radius = type.BarModelDiameter * 0.5;
        var edge = cover + radius;
        var b0 = e.MinX + edge; var b1 = e.MaxX - edge;
        var d0 = e.MinY + edge; var d1 = e.MaxY - edge;
        var arrayLength = d1 - d0;
        var zz = bottom ? surfaceZ + edge : surfaceZ - edge;
        if (b1 <= b0 || arrayLength <= Tolerance) return 0;
        var a = Compose(barAxis, b0, distributionAxis, d0, zAxis, zz);
        var b = Compose(barAxis, b1, distributionAxis, d0, zAxis, zz);
        var rebar = CreateRebar(doc, RebarStyle.Standard, type, host, zAxis, new List<Curve> { Line.CreateBound(a, b) });
        if (rebar is null) return 0;
        using var accessor = rebar.GetShapeDrivenAccessor();
        accessor.SetLayoutAsMaximumSpacing(Mm(spacingMm), arrayLength, true, true, true);
        Stamp(rebar, stamp);
        return 1;
    }

    private static AxisExtents SwapXy(AxisExtents e) => new(e.MinY, e.MaxY, e.MinX, e.MaxX, e.MinZ, e.MaxZ);

    public static RebarEngineResult CreateColumnStarters(Document doc, IReadOnlyList<FamilyInstance> columns, RebarStudioOptions options)
    {
        var foundations = new FilteredElementCollector(doc)
            .OfCategory(BuiltInCategory.OST_StructuralFoundation)
            .WhereElementIsNotElementType()
            .OfType<FamilyInstance>()
            .ToList();

        var type = RequireBarType(doc, options.ColumnStarterDiameterMm);
        var radius = type.BarModelDiameter * 0.5;
        var cover = Mm(options.CoverMm);
        var embed = Mm(options.ColumnStarterEmbedMm);
        var projection = Mm(options.ColumnStarterProjectionMm);
        var processed = 0;
        var skipped = 0;
        var created = 0;
        var notes = new List<string>();

        foreach (var column in columns)
        {
            var cBox = column.get_BoundingBox(null);
            if (cBox is null) { skipped++; continue; }
            var center = new XYZ((cBox.Min.X + cBox.Max.X) * 0.5, (cBox.Min.Y + cBox.Max.Y) * 0.5, cBox.Min.Z);
            var candidates = foundations
                .Select(f => new { Foundation = f, Box = f.get_BoundingBox(null) })
                .Where(x => x.Box is not null)
                .Where(x => center.X >= x.Box!.Min.X - Tolerance && center.X <= x.Box.Max.X + Tolerance &&
                            center.Y >= x.Box.Min.Y - Tolerance && center.Y <= x.Box.Max.Y + Tolerance)
                .OrderByDescending(x => x.Box!.Max.Z)
                .ToList();
            var target = candidates.FirstOrDefault(x => x.Box!.Max.Z <= cBox.Min.Z + Mm(500)) ?? candidates.FirstOrDefault();
            if (target is null) { skipped++; notes.Add($"Column {column.Id}: no foundation found below column center."); continue; }

            using var sub = new SubTransaction(doc);
            try
            {
                sub.Start();
                var t = column.GetTransform();
                var x = t.BasisX.Normalize();
                var y = t.BasisY.Normalize();
                var z = XYZ.BasisZ;
                if (!TryGetProjectedExtents(column, x, y, z, out var e)) throw new InvalidOperationException("Column extents unavailable.");
                var edge = cover + radius;
                var xs = new[] { e.MinX + edge, e.MaxX - edge };
                var ys = new[] { e.MinY + edge, e.MaxY - edge };
                var foundationTop = target.Box!.Max.Z;
                var z0 = foundationTop - embed;
                var z1 = Math.Max(foundationTop + projection, cBox.Min.Z + projection);
                if (z1 <= z0) throw new InvalidOperationException("Starter length is invalid.");
                var localCreated = 0;
                foreach (var xx in xs)
                foreach (var yy in ys)
                {
                    var a = Compose(x, xx, y, yy, z, z0);
                    var b = Compose(x, xx, y, yy, z, z1);
                    var rebar = CreateRebar(doc, RebarStyle.Standard, type, target.Foundation, x, new List<Curve> { Line.CreateBound(a, b) });
                    if (rebar is null) continue;
                    Stamp(rebar, "AP-Rebar Column Starter");
                    localCreated++;
                }
                if (localCreated == 0) throw new InvalidOperationException("Revit rejected starter bars for this foundation host.");
                sub.Commit();
                created += localCreated;
                processed++;
            }
            catch (Exception ex)
            {
                if (sub.GetStatus() == TransactionStatus.Started) sub.RollBack();
                skipped++;
                notes.Add($"Column {column.Id}: {ex.Message}");
            }
        }

        return new RebarEngineResult(processed, skipped, created, 0, notes.Take(12).ToList());
    }

    private static RebarBarType RequireBarType(Document doc, double diameterMm)
    {
        var type = FindClosestBarType(doc, diameterMm);
        if (type is null) throw new InvalidOperationException("No RebarBarType is loaded in this project.");
        return type;
    }

    public static RebarBarType? FindClosestBarType(Document doc, double diameterMm)
    {
        var target = Mm(diameterMm);
        return new FilteredElementCollector(doc).OfClass(typeof(RebarBarType)).Cast<RebarBarType>()
            .OrderBy(x => Math.Abs(x.BarNominalDiameter - target))
            .FirstOrDefault();
    }

    private static Rebar? CreateRebar(Document doc, RebarStyle style, RebarBarType barType, Element host, XYZ normal, IList<Curve> curves)
    {
#if REVIT2026_OR_GREATER
        using var terminations = new BarTerminationsData(doc);
        return Rebar.CreateFromCurves(doc, style, barType, host, normal, curves, terminations, true, true);
#else
        return Rebar.CreateFromCurves(doc, style, barType, null, null, host, normal, curves,
            RebarHookOrientation.Right, RebarHookOrientation.Right, true, true);
#endif
    }

    private static void Stamp(Rebar rebar, string value)
    {
        try
        {
            var p = rebar.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS);
            if (p is { IsReadOnly: false }) p.Set(value);
        }
        catch
        {
            // Metadata is non-critical.
        }
    }

    private static bool IsCategory(Element e, BuiltInCategory category)
    {
        var target = Category.GetCategory(e.Document, category);
        return target is not null && e.Category is not null && e.Category.Id.Equals(target.Id);
    }

    private sealed record AxisExtents(double MinX, double MaxX, double MinY, double MaxY, double MinZ, double MaxZ);

    private static bool TryGetProjectedExtents(Element element, XYZ x, XYZ y, XYZ z, out AxisExtents extents)
    {
        var points = GetGeometryPoints(element).ToList();
        if (points.Count < 4)
        {
            var box = element.get_BoundingBox(null);
            if (box is not null) points.AddRange(BoundingBoxCorners(box));
        }
        if (points.Count < 2)
        {
            extents = new AxisExtents(0, 0, 0, 0, 0, 0);
            return false;
        }
        var px = points.Select(p => p.DotProduct(x)).ToList();
        var py = points.Select(p => p.DotProduct(y)).ToList();
        var pz = points.Select(p => p.DotProduct(z)).ToList();
        extents = new AxisExtents(px.Min(), px.Max(), py.Min(), py.Max(), pz.Min(), pz.Max());
        return extents.MaxX > extents.MinX && extents.MaxY > extents.MinY && extents.MaxZ > extents.MinZ;
    }

    private static IEnumerable<XYZ> GetGeometryPoints(Element element)
    {
        var options = new Options { DetailLevel = ViewDetailLevel.Fine, IncludeNonVisibleObjects = false, ComputeReferences = false };
        var geometry = element.get_Geometry(options);
        if (geometry is null) yield break;
        foreach (var p in GeometryPoints(geometry)) yield return p;
    }

    private static IEnumerable<XYZ> GeometryPoints(GeometryElement geometry)
    {
        foreach (var obj in geometry)
        {
            switch (obj)
            {
                case Solid solid when solid.Volume > Tolerance:
                    foreach (Edge edge in solid.Edges)
                    {
                        var curve = edge.AsCurve();
                        yield return curve.GetEndPoint(0);
                        yield return curve.GetEndPoint(1);
                    }
                    break;
                case GeometryInstance instance:
                    foreach (var p in GeometryPoints(instance.GetInstanceGeometry())) yield return p;
                    break;
            }
        }
    }

    private static IEnumerable<XYZ> BoundingBoxCorners(BoundingBoxXYZ box)
    {
        for (var ix = 0; ix < 2; ix++)
        for (var iy = 0; iy < 2; iy++)
        for (var iz = 0; iz < 2; iz++)
        {
            var local = new XYZ(ix == 0 ? box.Min.X : box.Max.X, iy == 0 ? box.Min.Y : box.Max.Y, iz == 0 ? box.Min.Z : box.Max.Z);
            yield return box.Transform.OfPoint(local);
        }
    }

    private static IEnumerable<double> Linspace(double min, double max, int count)
    {
        if (count <= 0) yield break;
        if (count == 1)
        {
            yield return (min + max) * 0.5;
            yield break;
        }
        for (var i = 0; i < count; i++) yield return min + (max - min) * i / (count - 1.0);
    }

    private static XYZ Compose(XYZ x, double xv, XYZ y, double yv, XYZ z, double zv) =>
        x.Multiply(xv) + y.Multiply(yv) + z.Multiply(zv);

    private static double Mm(double mm) => UnitUtils.ConvertToInternalUnits(mm, UnitTypeId.Millimeters);
}
