using System.Globalization;

namespace AP.BimTools.Structure.RebarStudio;

internal static class RebarStudioSettingsStore
{
    private static readonly string Root = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "AP", "AP-BIM Tools", "Rebar");

    private static readonly string DefaultPath = Path.Combine(Root, "rebar-studio.ini");

    public static RebarStudioOptions Load()
    {
        var o = new RebarStudioOptions();
        try
        {
            if (!File.Exists(DefaultPath)) return o;
            var map = File.ReadAllLines(DefaultPath)
                .Where(x => !string.IsNullOrWhiteSpace(x) && !x.TrimStart().StartsWith("#"))
                .Select(x => x.Split(new[] { '=' }, 2))
                .Where(x => x.Length == 2)
                .ToDictionary(x => x[0].Trim(), x => x[1].Trim(), StringComparer.OrdinalIgnoreCase);

            foreach (var property in typeof(RebarStudioOptions).GetProperties().Where(p => p.CanWrite))
            {
                if (!map.TryGetValue(property.Name, out var raw)) continue;
                object? value = null;
                if (property.PropertyType == typeof(string)) value = raw;
                else if (property.PropertyType == typeof(bool) && bool.TryParse(raw, out var b)) value = b;
                else if (property.PropertyType == typeof(int) && int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out var i)) value = i;
                else if (property.PropertyType == typeof(double) && double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out var d)) value = d;
                else if (property.PropertyType.IsEnum && Enum.TryParse(property.PropertyType, raw, true, out var e)) value = e;
                if (value is not null) property.SetValue(o, value);
            }
        }
        catch
        {
            // Corrupt preferences should never prevent Revit from starting.
        }
        return o;
    }

    public static void Save(RebarStudioOptions options)
    {
        Directory.CreateDirectory(Root);
        var lines = new List<string>
        {
            "# AP-Rebar Studio settings",
            "# Values are millimetres unless noted otherwise."
        };
        foreach (var property in typeof(RebarStudioOptions).GetProperties().Where(p => p.CanRead))
        {
            var value = property.GetValue(options);
            var text = value switch
            {
                double d => d.ToString(CultureInfo.InvariantCulture),
                _ => Convert.ToString(value, CultureInfo.InvariantCulture) ?? ""
            };
            lines.Add($"{property.Name}={text}");
        }
        File.WriteAllLines(DefaultPath, lines);
    }

    public static string SettingsPath => DefaultPath;
}
