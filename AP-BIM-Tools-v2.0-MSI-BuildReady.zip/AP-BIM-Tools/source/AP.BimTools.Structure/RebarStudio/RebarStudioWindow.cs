using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace AP.BimTools.Structure.RebarStudio;

internal sealed class RebarStudioWindow : Window
{
    private readonly RebarStudioOptions _options;
    private readonly Dictionary<string, TextBox> _boxes = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, CheckBox> _checks = new(StringComparer.OrdinalIgnoreCase);
    private readonly TabControl _tabs = new();

    public RebarStudioOptions Options => _options;
    public bool SaveAsDefaults { get; private set; }

    public RebarStudioWindow(RebarStudioOptions initial, RebarStudioMode focusMode, int selectedCount)
    {
        _options = initial.Clone();
        if (focusMode != RebarStudioMode.Auto) _options.Mode = focusMode;

        Title = $"AP-Rebar Studio — {_options.Mode} — {selectedCount} host(s) selected";
        Width = 820;
        Height = 720;
        MinWidth = 760;
        MinHeight = 620;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        ResizeMode = ResizeMode.CanResize;
        Topmost = true;
        Background = Brushes.White;

        var root = new DockPanel { Margin = new Thickness(12) };
        var intro = new TextBlock
        {
            Text = "AP-Rebar Engine • Revit 2023–2027\nConfigure reinforcement, then Apply to the selected concrete hosts. Unsupported geometry is skipped instead of guessed.",
            Margin = new Thickness(0, 0, 0, 10),
            TextWrapping = TextWrapping.Wrap
        };
        DockPanel.SetDock(intro, Dock.Top);
        root.Children.Add(intro);

        var footer = BuildFooter();
        DockPanel.SetDock(footer, Dock.Bottom);
        root.Children.Add(footer);

        _tabs.Items.Add(BuildGeneralTab());
        _tabs.Items.Add(BuildBeamTab());
        _tabs.Items.Add(BuildColumnTab());
        _tabs.Items.Add(BuildWallTab());
        _tabs.Items.Add(BuildSlabTab());
        _tabs.Items.Add(BuildFoundationTab());
        SelectTab(focusMode);
        root.Children.Add(_tabs);
        Content = root;
    }

    private UIElement BuildFooter()
    {
        var panel = new DockPanel { Margin = new Thickness(0, 12, 0, 0) };
        var note = new TextBlock
        {
            Text = "Replace existing = delete hosted Rebar first. Use this only when the selected hosts are intended to be fully controlled by AP-Rebar.",
            VerticalAlignment = VerticalAlignment.Center,
            Foreground = Brushes.DimGray,
            TextWrapping = TextWrapping.Wrap,
            MaxWidth = 450
        };
        DockPanel.SetDock(note, Dock.Left);
        panel.Children.Add(note);

        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
        var save = new Button { Content = "Save defaults", MinWidth = 105, Height = 32, Margin = new Thickness(6, 0, 0, 0) };
        var apply = new Button { Content = "Apply", MinWidth = 105, Height = 32, Margin = new Thickness(6, 0, 0, 0), IsDefault = true };
        var cancel = new Button { Content = "Cancel", MinWidth = 105, Height = 32, Margin = new Thickness(6, 0, 0, 0), IsCancel = true };
        save.Click += (_, _) =>
        {
            if (!ReadUi()) return;
            SaveAsDefaults = true;
            RebarStudioSettingsStore.Save(_options);
            save.Content = "Saved";
        };
        apply.Click += (_, _) =>
        {
            if (!ReadUi()) return;
            DialogResult = true;
            Close();
        };
        buttons.Children.Add(save);
        buttons.Children.Add(apply);
        buttons.Children.Add(cancel);
        DockPanel.SetDock(buttons, Dock.Right);
        panel.Children.Add(buttons);
        return panel;
    }

    private TabItem BuildGeneralTab()
    {
        var panel = FormPanel();
        AddCheck(panel, nameof(RebarStudioOptions.ReplaceExisting), "Replace existing hosted rebar", _options.ReplaceExisting);
        AddDouble(panel, nameof(RebarStudioOptions.CoverMm), "Concrete cover", _options.CoverMm, "mm");
        AddText(panel, nameof(RebarStudioOptions.MarkPrefix), "Rebar mark prefix", _options.MarkPrefix);
        AddText(panel, nameof(RebarStudioOptions.PresetName), "Preset name", _options.PresetName);
        return Tab("General", panel);
    }

    private TabItem BuildBeamTab()
    {
        var panel = FormPanel();
        AddSection(panel, "LONGITUDINAL BARS");
        AddInt(panel, nameof(RebarStudioOptions.BeamTopCount), "Top bars — count", _options.BeamTopCount);
        AddDouble(panel, nameof(RebarStudioOptions.BeamTopDiameterMm), "Top bars — diameter", _options.BeamTopDiameterMm, "mm");
        AddInt(panel, nameof(RebarStudioOptions.BeamBottomCount), "Bottom bars — count", _options.BeamBottomCount);
        AddDouble(panel, nameof(RebarStudioOptions.BeamBottomDiameterMm), "Bottom bars — diameter", _options.BeamBottomDiameterMm, "mm");
        AddInt(panel, nameof(RebarStudioOptions.BeamExtraTopCount), "Extra top bars at supports — count", _options.BeamExtraTopCount);
        AddDouble(panel, nameof(RebarStudioOptions.BeamExtraTopDiameterMm), "Extra top bars — diameter", _options.BeamExtraTopDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.BeamExtraSupportRatio), "Extra top length / span", _options.BeamExtraSupportRatio, "0–0.50");
        AddSection(panel, "STIRRUP ZONES");
        AddDouble(panel, nameof(RebarStudioOptions.BeamStirrupDiameterMm), "Stirrup diameter", _options.BeamStirrupDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.BeamSupportZoneRatio), "Support zone length / span (each end)", _options.BeamSupportZoneRatio, "0–0.45");
        AddDouble(panel, nameof(RebarStudioOptions.BeamSupportSpacingMm), "Support-zone spacing", _options.BeamSupportSpacingMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.BeamMidSpacingMm), "Mid-span spacing", _options.BeamMidSpacingMm, "mm");
        return Tab("Beam Axis", panel);
    }

    private TabItem BuildColumnTab()
    {
        var panel = FormPanel();
        AddSection(panel, "MAIN BARS");
        AddInt(panel, nameof(RebarStudioOptions.ColumnBarsX), "Bars along X faces (incl. corners)", _options.ColumnBarsX);
        AddInt(panel, nameof(RebarStudioOptions.ColumnBarsY), "Bars along Y faces (incl. corners)", _options.ColumnBarsY);
        AddDouble(panel, nameof(RebarStudioOptions.ColumnMainDiameterMm), "Main bar diameter", _options.ColumnMainDiameterMm, "mm");
        AddSection(panel, "TIE ZONES");
        AddDouble(panel, nameof(RebarStudioOptions.ColumnTieDiameterMm), "Tie diameter", _options.ColumnTieDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.ColumnEndZoneRatio), "End zone height / column height", _options.ColumnEndZoneRatio, "0–0.45");
        AddDouble(panel, nameof(RebarStudioOptions.ColumnEndSpacingMm), "End-zone tie spacing", _options.ColumnEndSpacingMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.ColumnMidSpacingMm), "Middle-zone tie spacing", _options.ColumnMidSpacingMm, "mm");
        AddSection(panel, "COLUMN → FOUNDATION STARTERS");
        AddDouble(panel, nameof(RebarStudioOptions.ColumnStarterDiameterMm), "Starter bar diameter", _options.ColumnStarterDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.ColumnStarterEmbedMm), "Embed into foundation", _options.ColumnStarterEmbedMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.ColumnStarterProjectionMm), "Projection above foundation", _options.ColumnStarterProjectionMm, "mm");
        return Tab("Column", panel);
    }

    private TabItem BuildWallTab()
    {
        var panel = FormPanel();
        AddCheck(panel, nameof(RebarStudioOptions.WallBothFaces), "Reinforce both wall faces", _options.WallBothFaces);
        AddDouble(panel, nameof(RebarStudioOptions.WallVerticalDiameterMm), "Vertical bar diameter", _options.WallVerticalDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.WallVerticalSpacingMm), "Vertical bar spacing", _options.WallVerticalSpacingMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.WallHorizontalDiameterMm), "Horizontal bar diameter", _options.WallHorizontalDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.WallHorizontalSpacingMm), "Horizontal bar spacing", _options.WallHorizontalSpacingMm, "mm");
        AddSection(panel, "BOUNDARY REINFORCEMENT");
        AddInt(panel, nameof(RebarStudioOptions.WallBoundaryBars), "Extra vertical bars at each end / face", _options.WallBoundaryBars);
        AddDouble(panel, nameof(RebarStudioOptions.WallBoundaryDiameterMm), "Boundary bar diameter", _options.WallBoundaryDiameterMm, "mm");
        return Tab("Wall", panel);
    }

    private TabItem BuildSlabTab()
    {
        var panel = FormPanel();
        AddSection(panel, "BOTTOM MAT");
        AddDouble(panel, nameof(RebarStudioOptions.SlabBottomXDiameterMm), "Bottom X diameter", _options.SlabBottomXDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.SlabBottomXSpacingMm), "Bottom X spacing", _options.SlabBottomXSpacingMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.SlabBottomYDiameterMm), "Bottom Y diameter", _options.SlabBottomYDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.SlabBottomYSpacingMm), "Bottom Y spacing", _options.SlabBottomYSpacingMm, "mm");
        AddSection(panel, "TOP MAT");
        AddCheck(panel, nameof(RebarStudioOptions.SlabCreateTop), "Create top mat", _options.SlabCreateTop);
        AddDouble(panel, nameof(RebarStudioOptions.SlabTopXDiameterMm), "Top X diameter", _options.SlabTopXDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.SlabTopXSpacingMm), "Top X spacing", _options.SlabTopXSpacingMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.SlabTopYDiameterMm), "Top Y diameter", _options.SlabTopYDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.SlabTopYSpacingMm), "Top Y spacing", _options.SlabTopYSpacingMm, "mm");
        return Tab("Slab", panel);
    }

    private TabItem BuildFoundationTab()
    {
        var panel = FormPanel();
        AddSection(panel, "BOTTOM MAT");
        AddDouble(panel, nameof(RebarStudioOptions.FoundationBottomXDiameterMm), "Bottom X diameter", _options.FoundationBottomXDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.FoundationBottomXSpacingMm), "Bottom X spacing", _options.FoundationBottomXSpacingMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.FoundationBottomYDiameterMm), "Bottom Y diameter", _options.FoundationBottomYDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.FoundationBottomYSpacingMm), "Bottom Y spacing", _options.FoundationBottomYSpacingMm, "mm");
        AddSection(panel, "TOP MAT");
        AddCheck(panel, nameof(RebarStudioOptions.FoundationCreateTop), "Create top mat", _options.FoundationCreateTop);
        AddDouble(panel, nameof(RebarStudioOptions.FoundationTopXDiameterMm), "Top X diameter", _options.FoundationTopXDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.FoundationTopXSpacingMm), "Top X spacing", _options.FoundationTopXSpacingMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.FoundationTopYDiameterMm), "Top Y diameter", _options.FoundationTopYDiameterMm, "mm");
        AddDouble(panel, nameof(RebarStudioOptions.FoundationTopYSpacingMm), "Top Y spacing", _options.FoundationTopYSpacingMm, "mm");
        return Tab("Foundation", panel);
    }

    private static StackPanel FormPanel() => new() { Margin = new Thickness(14) };

    private static TabItem Tab(string header, UIElement child)
    {
        var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto, Content = child };
        return new TabItem { Header = header, Content = scroll };
    }

    private void AddSection(Panel panel, string title) => panel.Children.Add(new TextBlock
    {
        Text = title,
        FontWeight = FontWeights.SemiBold,
        Margin = new Thickness(0, 14, 0, 5),
        Foreground = Brushes.DimGray
    });

    private void AddText(Panel panel, string key, string label, string value)
    {
        var row = Row(label, out var valuePanel);
        var box = new TextBox { Text = value, Width = 220, Height = 26 };
        _boxes[key] = box;
        valuePanel.Children.Add(box);
        panel.Children.Add(row);
    }

    private void AddDouble(Panel panel, string key, string label, double value, string suffix)
    {
        var row = Row(label, out var valuePanel);
        var box = new TextBox { Text = value.ToString("0.###", CultureInfo.InvariantCulture), Width = 120, Height = 26 };
        _boxes[key] = box;
        valuePanel.Children.Add(box);
        valuePanel.Children.Add(new TextBlock { Text = suffix, Margin = new Thickness(8, 5, 0, 0), Foreground = Brushes.DimGray });
        panel.Children.Add(row);
    }

    private void AddInt(Panel panel, string key, string label, int value)
    {
        var row = Row(label, out var valuePanel);
        var box = new TextBox { Text = value.ToString(CultureInfo.InvariantCulture), Width = 120, Height = 26 };
        _boxes[key] = box;
        valuePanel.Children.Add(box);
        panel.Children.Add(row);
    }

    private void AddCheck(Panel panel, string key, string label, bool value)
    {
        var check = new CheckBox { Content = label, IsChecked = value, Margin = new Thickness(0, 7, 0, 7) };
        _checks[key] = check;
        panel.Children.Add(check);
    }

    private static Grid Row(string label, out StackPanel valuePanel)
    {
        var grid = new Grid { Margin = new Thickness(0, 4, 0, 4) };
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(360) });
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        var text = new TextBlock { Text = label, VerticalAlignment = VerticalAlignment.Center };
        valuePanel = new StackPanel { Orientation = Orientation.Horizontal };
        Grid.SetColumn(valuePanel, 1);
        grid.Children.Add(text);
        grid.Children.Add(valuePanel);
        return grid;
    }

    private bool ReadUi()
    {
        try
        {
            foreach (var kv in _boxes)
            {
                var property = typeof(RebarStudioOptions).GetProperty(kv.Key);
                if (property is null) continue;
                var raw = kv.Value.Text.Trim().Replace(',', '.');
                object value;
                if (property.PropertyType == typeof(string)) value = raw;
                else if (property.PropertyType == typeof(int))
                {
                    if (!int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out var i)) throw new FormatException(kv.Key);
                    value = i;
                }
                else if (property.PropertyType == typeof(double))
                {
                    if (!double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out var d)) throw new FormatException(kv.Key);
                    value = d;
                }
                else continue;
                property.SetValue(_options, value);
            }
            foreach (var kv in _checks)
            {
                var property = typeof(RebarStudioOptions).GetProperty(kv.Key);
                property?.SetValue(_options, kv.Value.IsChecked == true);
            }
            Validate();
            return true;
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Invalid value: {ex.Message}\nCheck counts, diameters, spacing and ratios.", "AP-Rebar Studio", MessageBoxButton.OK, MessageBoxImage.Warning);
            return false;
        }
    }

    private void Validate()
    {
        if (_options.CoverMm <= 0) throw new InvalidOperationException(nameof(_options.CoverMm));
        var counts = new[] { _options.BeamTopCount, _options.BeamBottomCount, _options.BeamExtraTopCount, _options.ColumnBarsX, _options.ColumnBarsY, _options.WallBoundaryBars };
        if (counts.Any(x => x < 0)) throw new InvalidOperationException("Bar counts must be non-negative.");
        if (_options.BeamTopCount is > 0 and < 2 || _options.BeamBottomCount is > 0 and < 2) throw new InvalidOperationException("Beam bar count must be 0 or at least 2.");
        if (_options.ColumnBarsX < 2 || _options.ColumnBarsY < 2) throw new InvalidOperationException("Column Bars X/Y must be at least 2.");
        if (_options.BeamSupportZoneRatio < 0 || _options.BeamSupportZoneRatio >= 0.5) throw new InvalidOperationException(nameof(_options.BeamSupportZoneRatio));
        if (_options.BeamExtraSupportRatio < 0 || _options.BeamExtraSupportRatio > 0.5) throw new InvalidOperationException(nameof(_options.BeamExtraSupportRatio));
        if (_options.ColumnEndZoneRatio < 0 || _options.ColumnEndZoneRatio >= 0.5) throw new InvalidOperationException(nameof(_options.ColumnEndZoneRatio));
        var positive = new[]
        {
            _options.BeamTopDiameterMm, _options.BeamBottomDiameterMm, _options.BeamStirrupDiameterMm,
            _options.ColumnMainDiameterMm, _options.ColumnTieDiameterMm, _options.ColumnStarterDiameterMm,
            _options.WallVerticalDiameterMm, _options.WallVerticalSpacingMm, _options.WallHorizontalDiameterMm, _options.WallHorizontalSpacingMm,
            _options.SlabBottomXDiameterMm, _options.SlabBottomXSpacingMm, _options.SlabBottomYDiameterMm, _options.SlabBottomYSpacingMm,
            _options.FoundationBottomXDiameterMm, _options.FoundationBottomXSpacingMm, _options.FoundationBottomYDiameterMm, _options.FoundationBottomYSpacingMm
        };
        if (positive.Any(x => x <= 0)) throw new InvalidOperationException("Diameters and spacing must be greater than zero.");
    }

    private void SelectTab(RebarStudioMode mode)
    {
        var index = mode switch
        {
            RebarStudioMode.Beam => 1,
            RebarStudioMode.Column => 2,
            RebarStudioMode.Wall => 3,
            RebarStudioMode.Slab => 4,
            RebarStudioMode.Foundation => 5,
            _ => 0
        };
        _tabs.SelectedIndex = index;
    }
}
