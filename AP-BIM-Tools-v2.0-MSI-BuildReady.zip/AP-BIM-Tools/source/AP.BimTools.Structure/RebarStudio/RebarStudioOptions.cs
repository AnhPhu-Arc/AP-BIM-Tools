namespace AP.BimTools.Structure.RebarStudio;

public enum RebarStudioMode
{
    Auto,
    Beam,
    Column,
    Wall,
    Slab,
    Foundation
}

public sealed class RebarStudioOptions
{
    public RebarStudioMode Mode { get; set; } = RebarStudioMode.Auto;
    public bool ReplaceExisting { get; set; } = true;
    public double CoverMm { get; set; } = 30;

    // Beam
    public int BeamTopCount { get; set; } = 3;
    public double BeamTopDiameterMm { get; set; } = 20;
    public int BeamBottomCount { get; set; } = 3;
    public double BeamBottomDiameterMm { get; set; } = 20;
    public int BeamExtraTopCount { get; set; } = 2;
    public double BeamExtraTopDiameterMm { get; set; } = 16;
    public double BeamExtraSupportRatio { get; set; } = 0.25;
    public double BeamStirrupDiameterMm { get; set; } = 8;
    public double BeamSupportZoneRatio { get; set; } = 0.25;
    public double BeamSupportSpacingMm { get; set; } = 100;
    public double BeamMidSpacingMm { get; set; } = 150;

    // Column
    public int ColumnBarsX { get; set; } = 4;
    public int ColumnBarsY { get; set; } = 4;
    public double ColumnMainDiameterMm { get; set; } = 20;
    public double ColumnTieDiameterMm { get; set; } = 8;
    public double ColumnEndZoneRatio { get; set; } = 0.20;
    public double ColumnEndSpacingMm { get; set; } = 100;
    public double ColumnMidSpacingMm { get; set; } = 150;
    public double ColumnStarterDiameterMm { get; set; } = 20;
    public double ColumnStarterEmbedMm { get; set; } = 500;
    public double ColumnStarterProjectionMm { get; set; } = 700;

    // Wall
    public double WallVerticalDiameterMm { get; set; } = 16;
    public double WallVerticalSpacingMm { get; set; } = 200;
    public double WallHorizontalDiameterMm { get; set; } = 12;
    public double WallHorizontalSpacingMm { get; set; } = 200;
    public bool WallBothFaces { get; set; } = true;
    public int WallBoundaryBars { get; set; } = 2;
    public double WallBoundaryDiameterMm { get; set; } = 20;

    // Slab
    public double SlabBottomXDiameterMm { get; set; } = 12;
    public double SlabBottomXSpacingMm { get; set; } = 200;
    public double SlabBottomYDiameterMm { get; set; } = 12;
    public double SlabBottomYSpacingMm { get; set; } = 200;
    public bool SlabCreateTop { get; set; } = true;
    public double SlabTopXDiameterMm { get; set; } = 10;
    public double SlabTopXSpacingMm { get; set; } = 200;
    public double SlabTopYDiameterMm { get; set; } = 10;
    public double SlabTopYSpacingMm { get; set; } = 200;

    // Foundation
    public double FoundationBottomXDiameterMm { get; set; } = 16;
    public double FoundationBottomXSpacingMm { get; set; } = 150;
    public double FoundationBottomYDiameterMm { get; set; } = 16;
    public double FoundationBottomYSpacingMm { get; set; } = 150;
    public bool FoundationCreateTop { get; set; } = true;
    public double FoundationTopXDiameterMm { get; set; } = 12;
    public double FoundationTopXSpacingMm { get; set; } = 200;
    public double FoundationTopYDiameterMm { get; set; } = 12;
    public double FoundationTopYSpacingMm { get; set; } = 200;

    // Documentation / data
    public string MarkPrefix { get; set; } = "AP-RB-";
    public string PresetName { get; set; } = "Default";

    public RebarStudioOptions Clone() => (RebarStudioOptions)MemberwiseClone();
}
