using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;
using AP.BimTools.Core.Services;

namespace AP.BimTools.Structure.RebarStudio;

internal static class RebarDocumentationService
{
    public static string ExportBbs(Document doc, IEnumerable<Rebar> rebars)
    {
        var items = rebars.ToList();
        var groups = items
            .Select(r => new
            {
                Rebar = r,
                Type = doc.GetElement(r.GetTypeId()) as RebarBarType,
                Mark = r.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString() ?? "",
                Quantity = Math.Max(1, r.get_Parameter(BuiltInParameter.REBAR_ELEM_QUANTITY_OF_BARS)?.AsInteger() ?? 1),
                TotalLength = Math.Max(0, r.get_Parameter(BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH)?.AsDouble() ?? 0),
                SingleLength = Math.Max(0, r.get_Parameter(BuiltInParameter.REBAR_ELEM_LENGTH)?.AsDouble() ?? 0)
            })
            .GroupBy(x => new
            {
                x.Mark,
                TypeName = x.Type?.Name ?? "",
                Diameter = x.Type?.BarNominalDiameter ?? 0,
                LengthBucket = Math.Round(UnitUtils.ConvertFromInternalUnits(x.SingleLength, UnitTypeId.Millimeters), 0)
            })
            .OrderBy(g => g.Key.Mark)
            .ThenBy(g => g.Key.Diameter)
            .ThenBy(g => g.Key.LengthBucket)
            .ToList();

        var rows = new List<string[]>
        {
            new[] { "Mark", "BarType", "Diameter_mm", "SingleLength_mm", "Quantity", "TotalLength_m", "EstimatedMass_kg", "HostCount" }
        };

        foreach (var g in groups)
        {
            var qty = g.Sum(x => x.Quantity);
            var totalFeet = g.Sum(x => x.TotalLength);
            var totalMeters = UnitUtils.ConvertFromInternalUnits(totalFeet, UnitTypeId.Meters);
            var diameterMm = UnitUtils.ConvertFromInternalUnits(g.Key.Diameter, UnitTypeId.Millimeters);
            var kgPerM = 0.006165 * diameterMm * diameterMm;
            var mass = totalMeters * kgPerM;
            var hostCount = g.Select(x => x.Rebar.GetHostId().ToString()).Distinct().Count();
            rows.Add(new[]
            {
                g.Key.Mark,
                g.Key.TypeName,
                diameterMm.ToString("0.#"),
                g.Key.LengthBucket.ToString("0"),
                qty.ToString(),
                totalMeters.ToString("0.###"),
                mass.ToString("0.##"),
                hostCount.ToString()
            });
        }

        return ReportService.WriteCsv("AP-Rebar-BBS", rows);
    }

    public static ViewSchedule CreateRebarSchedule(Document doc, string preferredName)
    {
        var category = Category.GetCategory(doc, BuiltInCategory.OST_Rebar)
            ?? throw new InvalidOperationException("Rebar category is unavailable.");
        var schedule = ViewSchedule.CreateSchedule(doc, category.Id);
        schedule.Name = UniqueViewName(doc, string.IsNullOrWhiteSpace(preferredName) ? "AP - Rebar Schedule" : preferredName);
        var definition = schedule.Definition;
        definition.IsItemized = false;

        var wanted = new[]
        {
            BuiltInParameter.ALL_MODEL_MARK,
            BuiltInParameter.REBAR_BAR_DIAMETER,
            BuiltInParameter.REBAR_ELEM_LENGTH,
            BuiltInParameter.REBAR_ELEM_QUANTITY_OF_BARS,
            BuiltInParameter.REBAR_ELEM_TOTAL_LENGTH
        };

        var fields = definition.GetSchedulableFields().ToList();
        foreach (var parameter in wanted)
        {
            var id = BuiltInParameterId(parameter);
            var field = fields.FirstOrDefault(x => x.ParameterId.Equals(id));
            if (field is not null)
            {
                try { definition.AddField(field); } catch { }
            }
        }
        return schedule;
    }

    public static View3D CreateReview3D(Document doc, IReadOnlyCollection<Element> hosts)
    {
        var viewType = new FilteredElementCollector(doc)
            .OfClass(typeof(ViewFamilyType))
            .Cast<ViewFamilyType>()
            .FirstOrDefault(x => x.ViewFamily == ViewFamily.ThreeDimensional)
            ?? throw new InvalidOperationException("No 3D ViewFamilyType found.");

        var view = View3D.CreateIsometric(doc, viewType.Id);
        view.Name = UniqueViewName(doc, "AP - Rebar Review 3D");
        view.DetailLevel = ViewDetailLevel.Fine;

        var hostIds = new HashSet<ElementId>(hosts.Select(x => x.Id));
        var rebars = new FilteredElementCollector(doc)
            .OfClass(typeof(Rebar))
            .Cast<Rebar>()
            .Where(r => hostIds.Contains(r.GetHostId()))
            .ToList();

        var all = hosts.Cast<Element>().Concat(rebars).ToList();
        var box = UnionBox(all, UnitUtils.ConvertToInternalUnits(300, UnitTypeId.Millimeters));
        if (box is not null)
        {
            view.IsSectionBoxActive = true;
            view.SetSectionBox(box);
        }

        foreach (var rebar in rebars)
        {
            try { rebar.SetUnobscuredInView(view, true); } catch { }
        }
        return view;
    }

    public static IReadOnlyList<ViewSection> CreateDetailSections(Document doc, IReadOnlyCollection<Element> hosts)
    {
        var sectionType = new FilteredElementCollector(doc)
            .OfClass(typeof(ViewFamilyType))
            .Cast<ViewFamilyType>()
            .FirstOrDefault(x => x.ViewFamily == ViewFamily.Section)
            ?? throw new InvalidOperationException("No Section ViewFamilyType found.");

        var result = new List<ViewSection>();
        foreach (var host in hosts)
        {
            try
            {
                var sectionBox = BuildSectionBox(host, UnitUtils.ConvertToInternalUnits(300, UnitTypeId.Millimeters));
                if (sectionBox is null) continue;
                var view = ViewSection.CreateSection(doc, sectionType.Id, sectionBox);
                view.Name = UniqueViewName(doc, $"AP - Rebar Detail - {HostLabel(host)}");
                view.DetailLevel = ViewDetailLevel.Fine;
                var rebars = new FilteredElementCollector(doc)
                    .OfClass(typeof(Rebar))
                    .Cast<Rebar>()
                    .Where(r => r.GetHostId().Equals(host.Id))
                    .ToList();
                foreach (var rebar in rebars)
                {
                    try { rebar.SetUnobscuredInView(view, true); } catch { }
                }
                result.Add(view);
            }
            catch
            {
                // Unsupported orientation/geometry is skipped so batch generation can continue.
            }
        }
        return result;
    }

    private static BoundingBoxXYZ? BuildSectionBox(Element host, double margin)
    {
        var world = host.get_BoundingBox(null);
        if (world is null) return null;
        var corners = new List<XYZ>();
        for (var ix = 0; ix < 2; ix++)
        for (var iy = 0; iy < 2; iy++)
        for (var iz = 0; iz < 2; iz++)
        {
            var p = new XYZ(ix == 0 ? world.Min.X : world.Max.X, iy == 0 ? world.Min.Y : world.Max.Y, iz == 0 ? world.Min.Z : world.Max.Z);
            corners.Add(world.Transform.OfPoint(p));
        }
        var center = new XYZ(corners.Average(p => p.X), corners.Average(p => p.Y), corners.Average(p => p.Z));
        var up = XYZ.BasisZ;
        XYZ viewDir;
        switch (host)
        {
            case FamilyInstance fi when fi.Location is LocationCurve { Curve: Line line }:
            {
                var axis = line.Direction.Normalize();
                viewDir = up.CrossProduct(axis).Normalize();
                break;
            }
            case FamilyInstance fi:
                viewDir = fi.GetTransform().BasisY.Normalize();
                break;
            case Wall wall:
                viewDir = wall.Orientation.Normalize();
                break;
            default:
                viewDir = XYZ.BasisY;
                break;
        }
        if (Math.Abs(viewDir.DotProduct(up)) > 0.95) viewDir = XYZ.BasisY;
        viewDir = new XYZ(viewDir.X, viewDir.Y, 0).Normalize();
        var right = viewDir.CrossProduct(up).Normalize();
        up = right.CrossProduct(viewDir).Normalize();

        var halfRight = corners.Max(p => Math.Abs((p - center).DotProduct(right))) + margin;
        var halfUp = corners.Max(p => Math.Abs((p - center).DotProduct(up))) + margin;
        var halfDepth = Math.Max(corners.Max(p => Math.Abs((p - center).DotProduct(viewDir))) + margin, UnitUtils.ConvertToInternalUnits(150, UnitTypeId.Millimeters));

        var t = Transform.Identity;
        t.Origin = center;
        t.BasisX = right;
        t.BasisY = up;
        t.BasisZ = viewDir;
        var sectionBox = new BoundingBoxXYZ
        {
            Transform = t,
            Min = new XYZ(-halfRight, -halfUp, -halfDepth),
            Max = new XYZ(halfRight, halfUp, halfDepth),
            Enabled = true
        };
        for (var dim = 0; dim < 3; dim++)
        {
            sectionBox.MinEnabled[dim] = true;
            sectionBox.MaxEnabled[dim] = true;
        }
        return sectionBox;
    }

    private static string HostLabel(Element host)
    {
        var category = host.Category?.Name ?? "Host";
        var mark = host.get_Parameter(BuiltInParameter.ALL_MODEL_MARK)?.AsString();
        return string.IsNullOrWhiteSpace(mark) ? $"{category} {host.Id}" : $"{category} {mark}";
    }

    private static BoundingBoxXYZ? UnionBox(IEnumerable<Element> elements, double margin)
    {
        var points = new List<XYZ>();
        foreach (var element in elements)
        {
            var box = element.get_BoundingBox(null);
            if (box is null) continue;
            for (var ix = 0; ix < 2; ix++)
            for (var iy = 0; iy < 2; iy++)
            for (var iz = 0; iz < 2; iz++)
            {
                var p = new XYZ(ix == 0 ? box.Min.X : box.Max.X, iy == 0 ? box.Min.Y : box.Max.Y, iz == 0 ? box.Min.Z : box.Max.Z);
                points.Add(box.Transform.OfPoint(p));
            }
        }
        if (points.Count == 0) return null;
        return new BoundingBoxXYZ
        {
            Min = new XYZ(points.Min(p => p.X) - margin, points.Min(p => p.Y) - margin, points.Min(p => p.Z) - margin),
            Max = new XYZ(points.Max(p => p.X) + margin, points.Max(p => p.Y) + margin, points.Max(p => p.Z) + margin)
        };
    }

    private static string UniqueViewName(Document doc, string baseName)
    {
        var names = new HashSet<string>(new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>().Select(v => v.Name), StringComparer.OrdinalIgnoreCase);
        if (!names.Contains(baseName)) return baseName;
        for (var i = 2; i < 999; i++)
        {
            var name = $"{baseName} {i}";
            if (!names.Contains(name)) return name;
        }
        return $"{baseName} {DateTime.Now:yyyyMMdd-HHmmss}";
    }

    private static ElementId BuiltInParameterId(BuiltInParameter parameter)
    {
#if REVIT2024_OR_GREATER
        return new ElementId((long)parameter);
#else
        return new ElementId((int)parameter);
#endif
    }
}
