using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Nice3point.Revit.Toolkit.External;
using AP.BimTools.Core;
using AP.BimTools.Core.Services;
using AP.BimTools.Core.UI;
using AP.BimTools.Core.Utilities;

namespace AP.BimTools.General.Commands;

internal static class GeneralHelpers
{
    public static List<Element> Instances(Document doc) => new FilteredElementCollector(doc).WhereElementIsNotElementType().ToElements().ToList();
    public static void Select(UIDocument uiDoc, IEnumerable<ElementId> ids) => uiDoc.Selection.SetElementIds(ids.Distinct().ToList());
    public static string CategoryName(Element e) => e.Category?.Name ?? "<No category>";
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ModelHealthCommand : ExternalCommand
{
    public override void Execute()
    {
        var doc = ActiveDocument;
        var all = GeneralHelpers.Instances(doc);
        var warnings = doc.GetWarnings();
        var imports = all.OfType<ImportInstance>().ToList();
        var links = all.OfType<RevitLinkInstance>().ToList();
        var views = new FilteredElementCollector(doc).OfClass(typeof(View)).Cast<View>().Count(v => !v.IsTemplate);
        var groups = new FilteredElementCollector(doc).OfClass(typeof(Group)).GetElementCount();
        var inPlace = new FilteredElementCollector(doc).OfClass(typeof(FamilyInstance)).Cast<FamilyInstance>()
            .Count(fi => fi.Symbol?.Family?.IsInPlace == true);
        var unpinnedLinks = links.Count(x => !x.Pinned);
        var linkedCad = imports.Count(x => x.IsLinked);
        var importedCad = imports.Count - linkedCad;
        var score = 100;
        score -= Math.Min(30, warnings.Count / 5);
        score -= Math.Min(15, importedCad * 3);
        score -= Math.Min(10, inPlace * 2);
        score -= Math.Min(10, unpinnedLinks * 2);
        score = Math.Max(0, score);

        var dialog = new TaskDialog(ProductInfo.Name)
        {
            MainInstruction = $"Model Health Score: {score}/100",
            MainContent = $"Project: {doc.Title}\nElements: {all.Count:N0}\nWarnings: {warnings.Count:N0}\nViews: {views:N0}\nRVT links: {links.Count:N0} (unpinned: {unpinnedLinks})\nCAD: {imports.Count:N0} (imported: {importedCad}, linked: {linkedCad})\nModel groups: {groups:N0}\nIn-place families: {inPlace:N0}",
            ExpandedContent = "Score is an AP-BIM heuristic for triage, not an Autodesk certification. Review warning severity and project BIM requirements before accepting a model."
        };
        dialog.Show();
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class WarningSummaryCommand : ExternalCommand
{
    public override void Execute()
    {
        var warnings = ActiveDocument.GetWarnings();
        if (warnings.Count == 0) { TaskDialog.Show(ProductInfo.Name, "No Revit warnings found."); return; }
        var groups = warnings.GroupBy(w => w.GetDescriptionText()).OrderByDescending(g => g.Count()).ToList();
        var text = string.Join("\n", groups.Take(20).Select((g, i) => $"{i + 1}. {g.Count()} × {g.Key}"));
        if (groups.Count > 20) text += $"\n… plus {groups.Count - 20} other warning types.";
        TaskDialog.Show(ProductInfo.Name, $"Total warnings: {warnings.Count}\n\n{text}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectSameCategoryCommand : ExternalCommand
{
    public override void Execute()
    {
        var seed = SelectionUtils.GetSeedElement(ActiveUiDocument, "Pick a seed element");
        if (seed?.Category is null) return;
        var ids = new FilteredElementCollector(ActiveDocument).WhereElementIsNotElementType()
            .Where(e => e.Category?.Id.Equals(seed.Category.Id) == true).Select(e => e.Id).ToList();
        GeneralHelpers.Select(ActiveUiDocument, ids);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class SelectSameTypeCommand : ExternalCommand
{
    public override void Execute()
    {
        var seed = SelectionUtils.GetSeedElement(ActiveUiDocument, "Pick a seed element");
        if (seed is null || seed.GetTypeId() == ElementId.InvalidElementId) return;
        var typeId = seed.GetTypeId();
        GeneralHelpers.Select(ActiveUiDocument, new FilteredElementCollector(ActiveDocument).WhereElementIsNotElementType().Where(e => e.GetTypeId().Equals(typeId)).Select(e => e.Id));
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class PinSelectedCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument);
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Pin selected", () =>
        {
            foreach (var e in selected) { try { if (!e.Pinned) { e.Pinned = true; changed++; } } catch { } }
        });
        TaskDialog.Show(ProductInfo.Name, $"Pinned {changed} element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class UnpinSelectedCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument);
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Unpin selected", () =>
        {
            foreach (var e in selected) { try { if (e.Pinned) { e.Pinned = false; changed++; } } catch { } }
        });
        TaskDialog.Show(ProductInfo.Name, $"Unpinned {changed} element(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class IsolateSelectedCommand : ExternalCommand
{
    public override void Execute()
    {
        var ids = ActiveUiDocument.Selection.GetElementIds();
        if (ids.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select elements first."); return; }
        TransactionUtils.Run(ActiveDocument, "AP - Temporary isolate", () => ActiveDocument.ActiveView.IsolateElementsTemporary(ids));
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ResetTempViewCommand : ExternalCommand
{
    public override void Execute()
    {
        var view = ActiveDocument.ActiveView;
        if (!view.IsTemporaryHideIsolateActive()) { TaskDialog.Show(ProductInfo.Name, "Temporary Hide/Isolate is not active."); return; }
        TransactionUtils.Run(ActiveDocument, "AP - Reset temporary view", () => view.DisableTemporaryViewMode(TemporaryViewMode.TemporaryHideIsolate));
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class PrefixViewsCommand : ExternalCommand
{
    public override void Execute()
    {
        var prefix = PromptDialog.AskText("AP - Prefix Views", "Prefix for all currently open views:", "AP-");
        if (string.IsNullOrWhiteSpace(prefix)) return;
        var openIds = ActiveUiDocument.GetOpenUIViews().Select(v => v.ViewId).Distinct().ToList();
        var views = openIds.Select(id => ActiveDocument.GetElement(id)).OfType<View>().Where(v => !v.IsTemplate && v is not ViewSheet).ToList();
        if (!PromptDialog.Confirm(ProductInfo.Name, $"Prefix {views.Count} open view(s) with '{prefix}'?")) return;
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Prefix open views", () =>
        {
            foreach (var view in views)
            {
                if (view.Name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) continue;
                try { view.Name = prefix + view.Name; changed++; } catch { }
            }
        });
        TaskDialog.Show(ProductInfo.Name, $"Renamed {changed} view(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class PrefixSheetsCommand : ExternalCommand
{
    public override void Execute()
    {
        var prefix = PromptDialog.AskText("AP - Prefix Sheets", "Prefix for sheet names:", "AP-");
        if (string.IsNullOrWhiteSpace(prefix)) return;
        var sheets = new FilteredElementCollector(ActiveDocument).OfClass(typeof(ViewSheet)).Cast<ViewSheet>().Where(s => !s.IsPlaceholder).ToList();
        if (!PromptDialog.Confirm(ProductInfo.Name, $"Prefix the NAME of all {sheets.Count} non-placeholder sheets? Sheet numbers will not change.")) return;
        var changed = 0;
        TransactionUtils.Run(ActiveDocument, "AP - Prefix sheet names", () =>
        {
            foreach (var sheet in sheets)
            {
                if (sheet.Name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) continue;
                try { sheet.Name = prefix + sheet.Name; changed++; } catch { }
            }
        });
        TaskDialog.Show(ProductInfo.Name, $"Renamed {changed} sheet(s).");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class LinkReportCommand : ExternalCommand
{
    public override void Execute()
    {
        var links = new FilteredElementCollector(ActiveDocument).OfClass(typeof(RevitLinkInstance)).Cast<RevitLinkInstance>().ToList();
        var rows = new List<string[]> { new[] { "Id", "Instance", "Type", "Status", "Pinned" } };
        foreach (var link in links)
        {
            var type = ActiveDocument.GetElement(link.GetTypeId()) as RevitLinkType;
            rows.Add([link.Id.ToString(), link.Name, type?.Name ?? "", type?.GetLinkedFileStatus().ToString() ?? "", link.Pinned.ToString()]);
        }
        var path = ReportService.WriteCsv("RVT_Links", rows);
        TaskDialog.Show(ProductInfo.Name, $"RVT links: {links.Count}\nReport: {path}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class CadImportReportCommand : ExternalCommand
{
    public override void Execute()
    {
        var imports = new FilteredElementCollector(ActiveDocument).OfClass(typeof(ImportInstance)).Cast<ImportInstance>().ToList();
        var rows = new List<string[]> { new[] { "Id", "Name", "Linked", "Pinned", "Owner View" } };
        foreach (var item in imports)
        {
            var owner = item.OwnerViewId == ElementId.InvalidElementId ? "Model" : ActiveDocument.GetElement(item.OwnerViewId)?.Name ?? "";
            rows.Add([item.Id.ToString(), item.Name, item.IsLinked.ToString(), item.Pinned.ToString(), owner]);
        }
        var path = ReportService.WriteCsv("CAD_Imports_Links", rows);
        TaskDialog.Show(ProductInfo.Name, $"CAD instances: {imports.Count}\nImported: {imports.Count(i => !i.IsLinked)}\nLinked: {imports.Count(i => i.IsLinked)}\nReport: {path}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class CoordinatesReportCommand : ExternalCommand
{
    public override void Execute()
    {
        var position = ActiveDocument.ActiveProjectLocation.GetProjectPosition(XYZ.Zero);
        var mm = UnitTypeId.Millimeters;
        var ew = UnitUtils.ConvertFromInternalUnits(position.EastWest, mm);
        var ns = UnitUtils.ConvertFromInternalUnits(position.NorthSouth, mm);
        var elev = UnitUtils.ConvertFromInternalUnits(position.Elevation, mm);
        var degrees = position.Angle * 180.0 / Math.PI;
        TaskDialog.Show(ProductInfo.Name, $"Active Project Location: {ActiveDocument.ActiveProjectLocation.Name}\nEast/West: {ew:N0} mm\nNorth/South: {ns:N0} mm\nElevation: {elev:N0} mm\nAngle to True North: {degrees:N4}°");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class ExportSelectionCommand : ExternalCommand
{
    public override void Execute()
    {
        var selected = SelectionUtils.GetSelectedElements(ActiveUiDocument);
        if (selected.Count == 0) { TaskDialog.Show(ProductInfo.Name, "Select elements first."); return; }
        var path = ReportService.WriteCsv("Selection", ModelDataService.ElementRows(selected));
        TaskDialog.Show(ProductInfo.Name, $"Exported {selected.Count} element(s).\n{path}");
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class PurgeUnusedCommand : ExternalCommand
{
    public override void Execute()
    {
        var id = RevitCommandId.LookupPostableCommandId(PostableCommand.PurgeUnused);
        if (!ActiveUiDocument.Application.CanPostCommand(id)) { TaskDialog.Show(ProductInfo.Name, "Revit cannot start Purge Unused in the current context."); return; }
        ActiveUiDocument.Application.PostCommand(id);
    }
}

[UsedImplicitly, Transaction(TransactionMode.Manual)]
public class AboutCommand : ExternalCommand
{
    public override void Execute()
    {
        TaskDialog.Show(ProductInfo.Name, $"{ProductInfo.Name} v{ProductInfo.Version}\n\nFour-discipline Revit productivity suite\nAP-ARCH | AP-STR | AP-MEP | AP-GEN\n\nBuilt on the Nice3point RevitTemplates architecture (MIT).\nDesigned for Revit 2023–2027.");
    }
}
