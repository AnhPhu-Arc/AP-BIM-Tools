namespace AP.BimTools.Core;

public static class ProductInfo
{
    public const string Name = "AP-BIM Tools";
    public const string Version = "1.1.0";
    public const string ArchitectureTab = "AP-ARCH";
    public const string StructureTab = "AP-STR";
    public const string MepTab = "AP-MEP";
    public const string GeneralTab = "AP-GEN";
    public const string VendorId = "APTL";
}
