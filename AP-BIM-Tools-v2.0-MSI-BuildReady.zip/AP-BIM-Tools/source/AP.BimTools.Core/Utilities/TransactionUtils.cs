using Autodesk.Revit.DB;

namespace AP.BimTools.Core.Utilities;

public static class TransactionUtils
{
    public static void Run(Document document, string name, Action action)
    {
        using var transaction = new Transaction(document, name);
        transaction.Start();
        try
        {
            action();
            transaction.Commit();
        }
        catch
        {
            if (transaction.GetStatus() == TransactionStatus.Started) transaction.RollBack();
            throw;
        }
    }
}
