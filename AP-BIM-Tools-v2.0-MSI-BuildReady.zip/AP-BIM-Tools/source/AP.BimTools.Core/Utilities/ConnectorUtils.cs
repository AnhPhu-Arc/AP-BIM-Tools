using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Electrical;
using Autodesk.Revit.DB.Mechanical;
using Autodesk.Revit.DB.Plumbing;

namespace AP.BimTools.Core.Utilities;

public static class ConnectorUtils
{
    public static IEnumerable<Connector> GetConnectors(Element element)
    {
        ConnectorSet? set = element switch
        {
            MEPCurve curve => curve.ConnectorManager?.Connectors,
            FamilyInstance fi when fi.MEPModel is not null => fi.MEPModel.ConnectorManager?.Connectors,
            _ => null
        };
        if (set is null) yield break;
        foreach (Connector connector in set) yield return connector;
    }

    public static IEnumerable<Connector> GetOpenPhysicalConnectors(Element element) =>
        GetConnectors(element).Where(c => c.ConnectorType == ConnectorType.End && !c.IsConnected);
}
