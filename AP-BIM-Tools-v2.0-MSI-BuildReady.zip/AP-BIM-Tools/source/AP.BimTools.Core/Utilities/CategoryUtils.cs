using Autodesk.Revit.DB;

namespace AP.BimTools.Core.Utilities;

public static class CategoryUtils
{
    public static bool Is(Element element, BuiltInCategory category)
    {
        var target = Category.GetCategory(element.Document, category);
        return target is not null && element.Category is not null && element.Category.Id.Equals(target.Id);
    }
}
