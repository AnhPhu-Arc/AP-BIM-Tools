using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.UI.Selection;

namespace AP.BimTools.Core.Utilities;

public static class SelectionUtils
{
    public static List<Element> GetSelectedElements(UIDocument uiDocument) =>
        uiDocument.Selection.GetElementIds().Select(id => uiDocument.Document.GetElement(id)).Where(e => e is not null).Cast<Element>().ToList();

    public static Element? GetSeedElement(UIDocument uiDocument, string prompt = "Select an element")
    {
        var selected = GetSelectedElements(uiDocument);
        if (selected.Count > 0) return selected[0];
        try
        {
            var reference = uiDocument.Selection.PickObject(ObjectType.Element, prompt);
            return uiDocument.Document.GetElement(reference);
        }
        catch (Autodesk.Revit.Exceptions.OperationCanceledException)
        {
            return null;
        }
    }

    public static XYZ GetRepresentativePoint(Element element)
    {
        return element.Location switch
        {
            LocationPoint lp => lp.Point,
            LocationCurve lc => lc.Curve.Evaluate(0.5, true),
            _ => element.get_BoundingBox(null) is { } box ? (box.Min + box.Max) * 0.5 : XYZ.Zero
        };
    }
}
