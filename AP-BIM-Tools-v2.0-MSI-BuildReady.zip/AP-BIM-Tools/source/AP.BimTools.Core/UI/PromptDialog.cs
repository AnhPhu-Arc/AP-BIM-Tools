using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using Autodesk.Revit.UI;

namespace AP.BimTools.Core.UI;

public static class PromptDialog
{
    public static string? AskText(string title, string label, string defaultValue = "")
    {
        var window = new Window
        {
            Title = title,
            Width = 420,
            Height = 175,
            WindowStartupLocation = WindowStartupLocation.CenterScreen,
            ResizeMode = ResizeMode.NoResize,
            Topmost = true
        };
        var grid = new Grid { Margin = new Thickness(14) };
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var text = new TextBlock { Text = label, Margin = new Thickness(0, 0, 0, 8) };
        var input = new TextBox { Text = defaultValue, MinWidth = 360, Height = 28 };
        var buttons = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 12, 0, 0) };
        var ok = new Button { Content = "OK", Width = 86, Height = 28, IsDefault = true, Margin = new Thickness(0,0,8,0) };
        var cancel = new Button { Content = "Cancel", Width = 86, Height = 28, IsCancel = true };
        ok.Click += (_, _) => { window.DialogResult = true; window.Close(); };
        buttons.Children.Add(ok); buttons.Children.Add(cancel);
        Grid.SetRow(text, 0); Grid.SetRow(input, 1); Grid.SetRow(buttons, 2);
        grid.Children.Add(text); grid.Children.Add(input); grid.Children.Add(buttons);
        window.Content = grid;
        input.SelectAll(); input.Focus();
        return window.ShowDialog() == true ? input.Text.Trim() : null;
    }

    public static double? AskDouble(string title, string label, double defaultValue = 0)
    {
        var text = AskText(title, label, defaultValue.ToString(CultureInfo.InvariantCulture));
        if (text is null) return null;
        if (double.TryParse(text.Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var value)) return value;
        TaskDialog.Show(ProductInfo.Name, "Giá trị nhập không hợp lệ.");
        return null;
    }

    public static bool Confirm(string title, string message)
    {
        var dialog = new TaskDialog(title)
        {
            MainInstruction = message,
            CommonButtons = TaskDialogCommonButtons.Yes | TaskDialogCommonButtons.No,
            DefaultButton = TaskDialogResult.No
        };
        return dialog.Show() == TaskDialogResult.Yes;
    }
}
