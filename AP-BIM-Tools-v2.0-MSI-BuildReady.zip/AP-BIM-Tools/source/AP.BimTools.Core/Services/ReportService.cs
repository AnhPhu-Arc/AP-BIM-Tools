using System.Diagnostics;
using System.Text;

namespace AP.BimTools.Core.Services;

public static class ReportService
{
    public static string ReportFolder
    {
        get
        {
            var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "AP-BIM Tools", "Reports");
            Directory.CreateDirectory(path);
            return path;
        }
    }

    public static string WriteCsv(string baseName, IEnumerable<string[]> rows)
    {
        var safe = string.Concat(baseName.Select(ch => Path.GetInvalidFileNameChars().Contains(ch) ? '_' : ch));
        var path = Path.Combine(ReportFolder, $"{safe}_{DateTime.Now:yyyyMMdd_HHmmss}.csv");
        using var writer = new StreamWriter(path, false, new UTF8Encoding(true));
        foreach (var row in rows) writer.WriteLine(string.Join(",", row.Select(Escape)));
        return path;
    }

    public static void OpenFolder()
    {
        try { Process.Start(new ProcessStartInfo(ReportFolder) { UseShellExecute = true }); }
        catch { /* Revit sandbox / corporate policies may block shell launch. */ }
    }

    private static string Escape(string? value)
    {
        value ??= string.Empty;
        return $"\"{value.Replace("\"", "\"\"")}\"";
    }
}
