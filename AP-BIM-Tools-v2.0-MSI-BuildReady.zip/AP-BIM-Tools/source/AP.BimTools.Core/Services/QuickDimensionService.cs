using Autodesk.Revit.DB;
using Autodesk.Revit.DB.Structure;

namespace AP.BimTools.Core.Services;

public sealed record QuickDimensionResult(int Created, int Skipped, string Message = "");

public static class QuickDimensionService
{
    private const double ParallelTolerance = 1e-4;

    private sealed record LinearReference(Reference Reference, Curve Curve, Element Element);

    public static QuickDimensionResult DimensionVisibleGrids(Document doc, View view, double offsetMm, IEnumerable<Grid>? source = null)
    {
        var selectedOrVisible = (source ?? new FilteredElementCollector(doc, view.Id)
            .OfClass(typeof(Grid)).Cast<Grid>())
            .Where(g => !g.IsHidden(view))
            .ToList();

        var items = new List<LinearReference>();
        foreach (var grid in selectedOrVisible)
        {
            var curve = GetDatumCurve(grid, view);
            if (curve is not Line) continue;
            items.Add(new LinearReference(new Reference(grid), curve, grid));
        }

        if (items.Count < 2) return new QuickDimensionResult(0, items.Count, "Need at least two visible straight grids in the active view.");
        return CreateParallelDimensions(doc, view, items, Mm(offsetMm), allowSingleElementWithTwoReferences: false);
    }

    public static QuickDimensionResult DimensionVisibleLevels(Document doc, View view, double offsetMm, IEnumerable<Level>? source = null)
    {
        if (view.ViewType is not (ViewType.Elevation or ViewType.Section))
            return new QuickDimensionResult(0, 0, "Level dimension works in elevation or section views.");

        var levels = (source ?? new FilteredElementCollector(doc, view.Id)
            .OfClass(typeof(Level)).Cast<Level>())
            .Where(l => !l.IsHidden(view))
            .ToList();

        var items = new List<LinearReference>();
        foreach (var level in levels)
        {
            var curve = GetDatumCurve(level, view);
            if (curve is not Line) continue;
            items.Add(new LinearReference(new Reference(level), curve, level));
        }

        if (items.Count < 2) return new QuickDimensionResult(0, items.Count, "Need at least two visible levels in the active view.");
        return CreateParallelDimensions(doc, view, items, Mm(offsetMm), allowSingleElementWithTwoReferences: false);
    }

    public static QuickDimensionResult DimensionWallFaces(Document doc, View view, IEnumerable<Wall> walls, double offsetMm)
    {
        if (!IsPlanView(view)) return new QuickDimensionResult(0, 0, "Wall Plan dimension works in floor/ceiling/engineering plan views.");

        var items = new List<LinearReference>();
        var skipped = 0;
        foreach (var wall in walls)
        {
            if (wall.Location is not LocationCurve { Curve: Line axis }) { skipped++; continue; }
            try
            {
                var ext = HostObjectUtils.GetSideFaces(wall, ShellLayerType.Exterior).FirstOrDefault();
                var inn = HostObjectUtils.GetSideFaces(wall, ShellLayerType.Interior).FirstOrDefault();
                if (ext is null || inn is null) { skipped++; continue; }
                items.Add(new LinearReference(ext, axis, wall));
                items.Add(new LinearReference(inn, axis, wall));
            }
            catch { skipped++; }
        }

        if (items.Count < 2) return new QuickDimensionResult(0, skipped, "Select one or more straight basic walls.");
        var result = CreateParallelDimensions(doc, view, items, Mm(offsetMm), allowSingleElementWithTwoReferences: true);
        return result with { Skipped = result.Skipped + skipped };
    }

    public static QuickDimensionResult DimensionFamilyCenters(Document doc, View view, IEnumerable<FamilyInstance> instances, double offsetMm)
    {
        if (!IsPlanView(view)) return new QuickDimensionResult(0, 0, "Pile/Column Plan dimension works in plan views.");
        var list = instances.Where(fi => fi.Location is LocationPoint).ToList();
        if (list.Count < 2) return new QuickDimensionResult(0, list.Count, "Need at least two point-based family instances.");

        var groups = GroupInstancesByOrientation(list, view);
        var created = 0;
        var skipped = list.Count - groups.Sum(g => g.Count);
        var offset = Mm(offsetMm);

        foreach (var group in groups)
        {
            if (group.Count < 2) { skipped += group.Count; continue; }
            var first = group[0];
            var transform = first.GetTransform();
            var xDir = ProjectToView(transform.BasisX, view).Normalize();
            var yDir = ProjectToView(transform.BasisY, view).Normalize();
            if (xDir.GetLength() < 1e-6 || yDir.GetLength() < 1e-6) { skipped += group.Count; continue; }

            var points = group.Select(fi => ((LocationPoint)fi.Location).Point).ToList();
            created += CreateFamilyReferenceDimension(doc, view, group, FamilyInstanceReferenceType.CenterLeftRight, xDir, yDir, points, offset) ? 1 : 0;
            created += CreateFamilyReferenceDimension(doc, view, group, FamilyInstanceReferenceType.CenterFrontBack, yDir, xDir, points, offset) ? 1 : 0;
        }

        return new QuickDimensionResult(created, skipped, created == 0 ? "No usable family center references were found. Family reference planes must be dimensionable (Is Reference ≠ Not a Reference)." : "");
    }

    private static bool CreateFamilyReferenceDimension(
        Document doc,
        View view,
        IReadOnlyList<FamilyInstance> instances,
        FamilyInstanceReferenceType referenceType,
        XYZ dimDirection,
        XYZ outsideDirection,
        IReadOnlyList<XYZ> points,
        double offset)
    {
        var refs = new ReferenceArray();
        foreach (var instance in instances)
        {
            try
            {
                var candidates = instance.GetReferences(referenceType);
                if (candidates is { Count: > 0 }) refs.Append(candidates[0]);
            }
            catch { }
        }
        if (refs.Size < 2) return false;

        var dimValues = points.Select(p => p.DotProduct(dimDirection)).ToList();
        var outValues = points.Select(p => p.DotProduct(outsideDirection)).ToList();
        var n = points.Average(p => p.DotProduct(view.ViewDirection));
        var outside = outValues.Max() + offset;
        var start = dimValues.Min() - offset * 0.35;
        var end = dimValues.Max() + offset * 0.35;
        var p0 = Compose(dimDirection, start, outsideDirection, outside, view.ViewDirection, n);
        var p1 = Compose(dimDirection, end, outsideDirection, outside, view.ViewDirection, n);

        try
        {
            doc.Create.NewDimension(view, Line.CreateBound(p0, p1), refs);
            return true;
        }
        catch { return false; }
    }

    private static QuickDimensionResult CreateParallelDimensions(Document doc, View view, IReadOnlyList<LinearReference> items, double offset, bool allowSingleElementWithTwoReferences)
    {
        var groups = GroupParallel(items);
        var created = 0;
        var skipped = 0;

        foreach (var group in groups)
        {
            var uniqueElements = group.Select(x => x.Element.Id).Distinct().Count();
            if (group.Count < 2 || (!allowSingleElementWithTwoReferences && uniqueElements < 2)) { skipped += group.Count; continue; }

            var d = ((Line)group[0].Curve).Direction.Normalize();
            d = CanonicalDirection(d, view);
            var dimDir = view.ViewDirection.CrossProduct(d).Normalize();
            if (dimDir.GetLength() < 1e-6) { skipped += group.Count; continue; }

            var refs = new ReferenceArray();
            foreach (var item in group) refs.Append(item.Reference);
            if (refs.Size < 2) { skipped += group.Count; continue; }

            var endpoints = group.SelectMany(x => new[] { x.Curve.GetEndPoint(0), x.Curve.GetEndPoint(1) }).ToList();
            var along = endpoints.Select(p => p.DotProduct(d)).ToList();
            var separated = endpoints.Select(p => p.DotProduct(dimDir)).ToList();
            var normal = endpoints.Average(p => p.DotProduct(view.ViewDirection));

            var fixedAlong = along.Max() + offset;
            var start = separated.Min() - offset * 0.35;
            var end = separated.Max() + offset * 0.35;
            var p0 = Compose(d, fixedAlong, dimDir, start, view.ViewDirection, normal);
            var p1 = Compose(d, fixedAlong, dimDir, end, view.ViewDirection, normal);

            try
            {
                doc.Create.NewDimension(view, Line.CreateBound(p0, p1), refs);
                created++;
            }
            catch { skipped += group.Count; }
        }

        return new QuickDimensionResult(created, skipped, created == 0 ? "No compatible parallel references were found for dimensioning." : "");
    }

    private static List<List<LinearReference>> GroupParallel(IReadOnlyList<LinearReference> items)
    {
        var result = new List<List<LinearReference>>();
        foreach (var item in items)
        {
            if (item.Curve is not Line line) continue;
            var dir = line.Direction.Normalize();
            var group = result.FirstOrDefault(g =>
            {
                var test = ((Line)g[0].Curve).Direction.Normalize();
                return Math.Abs(dir.DotProduct(test)) > 1 - ParallelTolerance;
            });
            if (group is null) result.Add([item]); else group.Add(item);
        }
        return result;
    }

    private static List<List<FamilyInstance>> GroupInstancesByOrientation(IReadOnlyList<FamilyInstance> instances, View view)
    {
        var result = new List<List<FamilyInstance>>();
        foreach (var instance in instances)
        {
            var x = ProjectToView(instance.GetTransform().BasisX, view);
            if (x.GetLength() < 1e-6) continue;
            x = x.Normalize();
            var group = result.FirstOrDefault(g =>
            {
                var gx = ProjectToView(g[0].GetTransform().BasisX, view);
                return gx.GetLength() > 1e-6 && Math.Abs(gx.Normalize().DotProduct(x)) > 0.9995;
            });
            if (group is null) result.Add([instance]); else group.Add(instance);
        }
        return result;
    }

    private static Curve? GetDatumCurve(DatumPlane datum, View view)
    {
        try
        {
            var curves = datum.GetCurvesInView(DatumExtentType.ViewSpecific, view);
            var line = curves.OfType<Line>().FirstOrDefault();
            if (line is not null) return line;
        }
        catch { }
        try
        {
            return datum.GetCurvesInView(DatumExtentType.Model, view).OfType<Line>().FirstOrDefault();
        }
        catch { return null; }
    }

    private static XYZ ProjectToView(XYZ v, View view)
    {
        var n = view.ViewDirection.Normalize();
        return v - n.Multiply(v.DotProduct(n));
    }

    private static XYZ CanonicalDirection(XYZ d, View view)
    {
        var right = view.RightDirection.Normalize();
        var up = view.UpDirection.Normalize();
        if (Math.Abs(d.DotProduct(right)) >= Math.Abs(d.DotProduct(up)))
            return d.DotProduct(right) < 0 ? d.Multiply(-1.0) : d;
        return d.DotProduct(up) < 0 ? d.Multiply(-1.0) : d;
    }

    private static XYZ Compose(XYZ a, double av, XYZ b, double bv, XYZ c, double cv) =>
        a.Multiply(av) + b.Multiply(bv) + c.Multiply(cv);

    private static bool IsPlanView(View view) => view.ViewType is ViewType.FloorPlan or ViewType.CeilingPlan or ViewType.EngineeringPlan;

    private static double Mm(double mm) => UnitUtils.ConvertToInternalUnits(mm, UnitTypeId.Millimeters);
}
