using Autodesk.Revit.DB;
using AP.BimTools.Core.Utilities;

namespace AP.BimTools.Core.Services;

public static class RenumberService
{
    public static int Renumber(Document document, IEnumerable<Element> elements, BuiltInParameter builtInParameter, string prefix, int start, int digits)
    {
        var ordered = elements.OrderByDescending(e => SelectionUtils.GetRepresentativePoint(e).Y)
            .ThenBy(e => SelectionUtils.GetRepresentativePoint(e).X)
            .ToList();
        var index = start;
        var changed = 0;
        foreach (var element in ordered)
        {
            var parameter = element.get_Parameter(builtInParameter);
            if (parameter is null || parameter.IsReadOnly || parameter.StorageType != StorageType.String) continue;
            parameter.Set(prefix + index.ToString($"D{Math.Max(1, digits)}"));
            index++;
            changed++;
        }
        return changed;
    }
}
