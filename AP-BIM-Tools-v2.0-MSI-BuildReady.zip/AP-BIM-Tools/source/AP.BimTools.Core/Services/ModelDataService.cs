using Autodesk.Revit.DB;

namespace AP.BimTools.Core.Services;

public static class ModelDataService
{
    public static IEnumerable<string[]> ElementRows(IEnumerable<Element> elements)
    {
        yield return ["Id", "Category", "Family/Type", "Name", "Level"];
        foreach (var e in elements)
        {
            var category = e.Category?.Name ?? "";
            var type = e.Document.GetElement(e.GetTypeId())?.Name ?? "";
            var level = e.Document.GetElement(e.LevelId)?.Name ?? "";
            yield return [e.Id.ToString(), category, type, e.Name ?? "", level];
        }
    }
}
