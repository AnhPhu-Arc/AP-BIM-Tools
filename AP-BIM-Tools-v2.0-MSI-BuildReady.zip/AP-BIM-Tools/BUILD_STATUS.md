# Build status — AP-BIM Tools 2.0

Static consistency checks completed in the ChatGPT workspace:
- 4 ribbon tabs: AP-ARCH, AP-STR, AP-MEP, AP-GEN.
- 87 concrete `*Command` classes in source.
- 83 ribbon command references after AP-Rebar 2.0 expansion; 0 missing referenced command classes.
- Legacy v1.1 Beam 4 Bars / Beam Stirrups / Column 4 Bars / Column Ties classes remain in source for compatibility but are no longer primary ribbon entry points.
- AP-Rebar uses per-host `SubTransaction` rollback so unsupported/failed hosts do not lose existing reinforcement during replace workflows.
- Project/manifest XML parsing passes.
- Nice3point RevitTemplates 6.2.3 multi-version configuration remains Revit 2023–2027.
- New code avoids relying on Revit 2024-only `ElementId.Value`; version-specific `ElementId` construction is conditional where required.

Binary/MSI compilation was not executed in this Linux workspace because the .NET SDK/Revit/NuGet build environment is not present. The repository includes `build-release.ps1` and GitHub Actions for Windows restore/build/package. Production use still requires compile + Revit smoke tests against each target version and representative project families.
