# AP-Rebar 2.0 changelog

Compared with AP-BIM Tools v1.1:

- Replaced the primary 4-bars/stirrups ribbon workflow with AP-Rebar Studio.
- Added Beam Rebar Axis configuration: top/bottom bars, support extras, support/mid stirrup zones.
- Added configurable Column perimeter reinforcement and three tie zones.
- Added Column → Foundation starter bars.
- Added Wall vertical/horizontal two-face reinforcement + boundary bars.
- Added Slab bottom/top X/Y mats.
- Added Foundation bottom/top X/Y mats.
- Added persistent rebar presets/defaults.
- Added per-host SubTransaction rollback during batch replace.
- Added Apply Saved Preset and Clear Host Rebar.
- Added AP-generated rebar selection metadata.
- Added BBS CSV aggregation with estimated mass.
- Added native Revit Rebar Schedule creation.
- Added cropped 3D rebar review views.
- Added automatic detail section views for supported host orientations.
- Retained Quick Dim: Grid / Level / Wall Plan / Pile Plan / Column Plan.
- Retained legacy v1.1 rebar command classes in source for compatibility, but removed them from the primary ribbon.
